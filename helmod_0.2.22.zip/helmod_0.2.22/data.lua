require("core.defines")
require("prototypes.fonts")
require("prototypes.style")