data:extend{
  {
    type = "armor",
    name = "tiny-armor",
    icon = "__TinyStart__/graphics/icons/tiny-power-armor.png",
    flags = {"goes-to-main-inventory"},
    resistances =
    {
      {
        type = "physical",
        decrease = 6,
        percent = 30
      },
      {
        type = "acid",
        decrease = 5,
        percent = 30
      },
      {
        type = "explosion",
        decrease = 10,
        percent = 30
      },
      {
        type = "fire",
        decrease = 0,
        percent = 40
      }
    },
    durability = 5000,
    subgroup = "armor",
    order = "a[tiny-armor]",
    stack_size = 1,
    equipment_grid = "tiny-equipment-grid",
    inventory_size_bonus = 10
  },
  {
    type = "equipment-grid",
    name = "tiny-equipment-grid",
    width = 5,
    height = 4,
    equipment_categories = {"armor"}
  },
  {
    type = "generator-equipment",
    name = "micro-fusion-reactor-equipment",
    sprite =
    {
      filename = "__TinyStart__/graphics/equipment/tiny-fusion-reactor-equipment.png",
      width = 128,
      height = 128,
      priority = "medium"
    },
    shape =
    {
      width = 2,
      height = 2,
      type = "full"
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "primary-output"
    },
    power = "150kW",
    categories = {"armor"}
  },
  {
    type = "item",
    name = "micro-fusion-reactor-equipment",
    icon = "__TinyStart__/graphics/icons/tiny-fusion-reactor-equipment.png",
    placed_as_equipment_result = "micro-fusion-reactor-equipment",
    flags = {"goes-to-main-inventory"},
    subgroup = "equipment",
    order = "a[energy-source]-b[fusion-reactor]",
    stack_size = 20
  },
}  