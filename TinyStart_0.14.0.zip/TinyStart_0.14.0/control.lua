script.on_event(defines.events.on_player_created, function(event)
	local player = game.players[event.player_index]
	--filters
		local inventory = player.get_inventory(defines.inventory.player_quickbar)
		inventory.clear()
		inventory.set_filter(1,"transport-belt")
		inventory.set_filter(2,"inserter")
		inventory.set_filter(3,"underground-belt")
		inventory.set_filter(4,"splitter")
		inventory.set_filter(5,"small-electric-pole")
		inventory.set_filter(6,"assembling-machine-1")
		inventory.set_filter(7,"long-handed-inserter")
		inventory.set_filter(8,"blueprint-book")
		inventory.set_filter(9,"deconstruction-planner")
		inventory.set_filter(10,"steel-chest")
	-- armor
		player.insert{name="tiny-armor", count = 1}
		local p_armor = player.get_inventory(5)[1].grid --defines.inventory.player_armor = 5?
			p_armor.put({name = "micro-fusion-reactor-equipment"})
			p_armor.put({name = "energy-shield-equipment"})
			p_armor.put({name = "personal-roboport-equipment"})
			p_armor.put({name = "personal-roboport-equipment"})
			p_armor.put({name = "battery-mk2-equipment"})
			p_armor.put({name = "battery-mk2-equipment"})
		player.insert{name="construction-robot", count = 20}
		player.insert{name="blueprint-book", count = 1}
		local book = player.get_inventory(defines.inventory.player_quickbar).find_item_stack("blueprint-book").get_inventory(defines.inventory.item_main)
		book.insert{name="blueprint", count = 20}
		player.insert{name="deconstruction-planner", count = 1}
end)

script.on_event(defines.events.on_player_respawned, function(event)
	local player = game.players[event.player_index]
		player.insert{name="tiny-armor", count = 1}
		local p_armor = player.get_inventory(5)[1].grid
			p_armor.put({name = "micro-fusion-reactor-equipment"})
			p_armor.put({name = "energy-shield-equipment"})
			p_armor.put({name = "personal-roboport-equipment"})
			p_armor.put({name = "personal-roboport-equipment"})
			p_armor.put({name = "battery-mk2-equipment"})	  
			p_armor.put({name = "battery-mk2-equipment"})
		player.insert{name="construction-robot", count = 20}
		player.insert{name="blueprint-book", count = 1}
		if player.get_inventory(defines.inventory.player_quickbar).find_item_stack("blueprint-book") ~= nil then
			local book = player.get_inventory(defines.inventory.player_quickbar).find_item_stack("blueprint-book").get_inventory(defines.inventory.item_main)
			book.insert{name="blueprint", count = 20}
		elseif player.get_inventory(defines.inventory.player_main).find_item_stack("blueprint-book") ~= nil then
			local book = player.get_inventory(defines.inventory.player_main).find_item_stack("blueprint-book").get_inventory(defines.inventory.item_main)
			book.insert{name="blueprint", count = 20}
		end
		player.insert{name="deconstruction-planner", count = 1}
end)