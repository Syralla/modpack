--wether you want more powerfull tools, default true
add_tools = true
--wether you want larger powerpoles/substations, default true
add_entities = true
--wether you want cheat modules, default true
cheat_modules = true