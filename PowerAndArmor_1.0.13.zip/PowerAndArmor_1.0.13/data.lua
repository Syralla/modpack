require("config")

require("prototypes.item")
require("prototypes.equipment")
require("prototypes.equipment-grid")
require("prototypes.recipe")
require("prototypes.technology")

--optional features
if add_entities then
	require("prototypes.entities")
end

if cheat_modules then
	require("prototypes.module")
end

--unhides the railgun and railgun darts
data.raw["gun"]["railgun"].flags = {"goes-to-main-inventory"}
data.raw["ammo"]["railgun-dart"].flags = {"goes-to-main-inventory"}