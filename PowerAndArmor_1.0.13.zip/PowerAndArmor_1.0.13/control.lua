script.on_configuration_changed(function(data)
	if data.mod_changes ~= nil and data.mod_changes["PowerAndArmor"] ~= nil and data.mod_changes["PowerAndArmor"].old_version ~= nil then
	--mod has been added to a new save
		for _,force in pairs(game.forces) do
			force.reset_recipes()
			force.reset_technologies()

			local techs=force.technologies
			local recipes=force.recipes

			if techs["power-armor"].researched then
				recipes["modular-armor-upgrade"].enabled=true
			end
			if techs["power-armor-2"].researched then
				recipes["power-armor-upgrade"].enabled=true
			end
		end	
	end
	
	if data.mod_changes ~= nil and data.mod_changes["PowerAndArmor"] ~= nil and data.mod_changes["PowerAndArmor"].old_version == nil then
	--mod has been updated
		for _,force in pairs(game.forces) do
			force.reset_recipes()
			force.reset_technologies()

			local techs=force.technologies
			local recipes=force.recipes

			if techs["power-armor"].researched then
				recipes["modular-armor-upgrade"].enabled=true
			end
			if techs["power-armor-2"].researched then
				recipes["power-armor-upgrade"].enabled=true
			end
		end	
	end
end)

script.on_init(function()
	--Nothing yet
end)   
  
script.on_load(function()
	--Nothing yet
end)