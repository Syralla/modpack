data:extend({
{
	type = "equipment-grid",
	name = "xlarge-equipment_grid",
	width = 20,
	height = 20,
	equipment_categories = {"armor"}
}
})