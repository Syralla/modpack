--recipes for armor
data:extend(
{
	{
		type = "recipe",
		name = "power-armor-mk3",
		enabled = "false",
		ingredients =
		{
			{"effectivity-module-3", 10},
			{"speed-module-3", 10},
			{"productivity-module-3", 10},
			{"processing-unit", 300},
			{"steel-plate", 100},
			{"alien-artifact", 100},
		},
		result = "power-armor-mk3",
		category = "crafting",
		energy_required = 25,
	},
	{
		type = "recipe",
		name = "modular-armor-upgrade",
		enabled = "false",
		ingredients =
		{
			{"electric-engine-unit",20},
			{"steel-plate", 50},
			{"alien-artifact" ,10},
			{"modular-armor", 1}
		},
		result = "power-armor"
	},
	{
		type = "recipe",
		name = "power-armor-upgrade",
		enabled = "false",
		ingredients =
		{
			{"effectivity-module-3", 5},
			{"speed-module-3", 5},
			{"alien-artifact", 40},
			{"power-armor" ,1}
		},
		result = "power-armor-mk2"
	},
	{
		type = "recipe",
		name = "power-armor-mk2-upgrade",
		enabled = "false",
		ingredients =
		{
			{"effectivity-module-3", 5},
			{"speed-module-3", 5},
			{"productivity-module-3", 10},
			{"processing-unit", 50},
			{"steel-plate", 50},
			{"alien-artifact", 50},
			{"power-armor-mk2", 1}
		},
		result = "power-armor-mk3"
	}
})
-- recipes for equipment
data:extend(
{
	{
		type = "recipe",
		name = "night-vision-equipment-mk2",
		enabled = "false",
		energy_required = 10,
		ingredients =
		{
			{"night-vision-equipment", 1},
			{"processing-unit", 1},
		},
		result = "night-vision-equipment-mk2",
	},
	{
		type = "recipe",
		name = "fusion-reactor-equipment-mk2",
		enabled = "false",
		energy_required = 10,
		ingredients =
		{
			{"fusion-reactor-equipment", 1},
			{"processing-unit", 5},
			{"effectivity-module-3", 1},
		},
		result = "fusion-reactor-equipment-mk2",
	},
	{
		type = "recipe",
		name = "exoskeleton-equipment-mk2",
		enabled = "false",
		energy_required = 10,
		ingredients =
		{
			{"exoskeleton-equipment", 1},
			{"advanced-circuit", 10},
			{"iron-gear-wheel", 30},
			{"speed-module", 1},
			{"steel-plate", 20},
		},
		result = "exoskeleton-equipment-mk2",
	},
	{
		type = "recipe",
		name = "personal-roboport-equipment-mk2",
		enabled = false,
		energy_required = 10,
		ingredients =
		{
			{"personal-roboport-equipment", 2},
			{"processing-unit", 10},
			{"battery", 45},
		},
		result = "personal-roboport-equipment-mk2"
	},
	{
		type = "recipe",
		name = "energy-shield-mk3-equipment",
		enabled = false,
		energy_required = 10,
		ingredients =
		{
			{"energy-shield-mk2-equipment", 2},
			{"processing-unit", 10}
		},
		result = "energy-shield-mk3-equipment"
	},
	{
		type = "recipe",
		name = "battery-equipment-mk3",
		enabled = false,
		energy_required = 10,
		ingredients =
		{
			{"battery-mk2-equipment", 2},
			{"effectivity-module", 1}
		},
		result = "battery-equipment-mk3"
	},
	{
		type = "recipe",
		name = "personal-laser-defense-equipment-mk2",
		enabled = false,
		energy_required = 10,
		ingredients =
		{
			{"productivity-module", 1},
			{"personal-laser-defense-equipment", 1},
			{"laser-turret", 5}
		},
		result = "personal-laser-defense-equipment-mk2"
	},
})
--recipes for tools
if add_tools then
	data:extend(
	{
		{
			type = "recipe",
			name = "steel-drill",
			enabled = false,
			ingredients =
			{
				{"steel-plate", 5},
				{"electric-engine-unit", 1},
				{"electronic-circuit", 5}
			},
			result = "steel-drill"
		},
		{
			type = "recipe",
			name = "alien-steel-drill",
			enabled = false,
			ingredients =
			{
				{"steel-drill", 1},
				{"alien-artifact", 1},
			},
			result = "alien-steel-drill"
		},
	})
end
--recipes for power
if add_entities then
	data:extend({
		{
			type = "recipe",
			name = "supercharged-medium-electric-pole",
			enabled = false,
			ingredients = 
			{
				{"medium-electric-pole", 1},
				{"copper-cable", 10},
				{"red-wire", 10},
				{"green-wire", 10}
			},
			result = "supercharged-medium-electric-pole"
		},
		{
			type = "recipe",
			name = "supercharged-substation",
			enabled = false,
			ingredients = 
			{
				{"substation", 1},
				{"copper-cable", 10},
				{"red-wire", 10},
				{"green-wire", 10}
			},
			result = "supercharged-substation"
		}
	})
end