--Armor
data:extend(
{
	{
		type = "armor",
		name = "power-armor-mk3",
		icon = "__PowerAndArmor__/graphics/icons/power-armor-mk3.png",
		flags = {"goes-to-main-inventory"},
		resistances = 
		{
			{
				type = "physical",
				decrease = 20,
				percent = 50
			},
			{
				type = "acid",
				decrease = 20,
				percent = 50
			},
			{
				type = "explosion",
				decrease = 20,
				percent = 50
			},
			{
				type = "impact",
				decrease = 20,
				percent = 50
			},
			{
				type = "poison",
				decrease = 20,
				percent = 50
			},
			{
				type = "fire",
				decrease = 20,
				percent = 50
			},
			{
				type = "laser",
				decrease = 20,
				percent = 50
			},
		},
		durability = 50000,
		subgroup = "armor",
		order = "f[power-armor-mk3]",
		stack_size = 1,
		equipment_grid = "xlarge-equipment_grid",
		inventory_size_bonus = 40
	}
})
--Equipment
data:extend(
{
	{
		type = "item",
		name = "night-vision-equipment-mk2",
		icon = "__PowerAndArmor__/graphics/icons/night-vision-equipment-mk2.png",
		placed_as_equipment_result = "night-vision-equipment-mk2",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "f[night-vision]-a[night-vision-equipment]",
		stack_size = 20
	},
	{
		type = "item",
		name = "fusion-reactor-equipment-mk2",
		icon = "__PowerAndArmor__/graphics/icons/fusion-reactor-equipment-mk2.png",
		placed_as_equipment_result = "fusion-reactor-equipment-mk2",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "a[energy-source]-b[fusion-reactor]",
		stack_size = 20
	},
	{
		type = "item",
		name = "exoskeleton-equipment-mk2",
		icon = "__PowerAndArmor__/graphics/icons/exoskeleton-equipment-mk2.png",
		placed_as_equipment_result = "exoskeleton-equipment-mk2",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "e[exoskeleton]-a[exoskeleton-equipment]",
		stack_size = 10
	},
	{
		type = "item",
		name = "personal-roboport-equipment-mk2",
		icon = "__PowerAndArmor__/graphics/icons/personal-roboport-equipment-mk2.png",
		placed_as_equipment_result = "personal-roboport-equipment-mk2",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "e[robotics]-a[personal-roboport-equipment]",
		stack_size = 5
	},
	{
		type = "item",
		name = "energy-shield-mk3-equipment",
		icon = "__PowerAndArmor__/graphics/icons/energy-shield-mk3-equipment.png",
		placed_as_equipment_result = "energy-shield-mk3-equipment",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "b[shield]-b[energy-shield-equipment-mk2]",
		stack_size = 50,
		default_request_amount = 10
	},
	{
		type = "item",
		name = "battery-equipment-mk3",
		icon = "__PowerAndArmor__/graphics/icons/battery-equipment-mk3.png",
		placed_as_equipment_result = "battery-equipment-mk3",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "c[battery]-b[battery-mk2-equipment]",
		stack_size = 50,
		default_request_amount = 10
	},
	{
		type = "item",
		name = "personal-laser-defense-equipment-mk2",
		icon = "__PowerAndArmor__/graphics/icons/personal-laser-defense-equipment-mk2.png",
		placed_as_equipment_result = "personal-laser-defense-equipment-mk2",
		flags = {"goes-to-main-inventory"},
		subgroup = "equipment",
		order = "d[active-defense]-a[personal-laser-defense-equipment]",
		stack_size = 20
	},
 })
 --tools
 if add_tools then
	data:extend(
	{
		{
			type = "mining-tool",
			name = "steel-drill",
			icon = "__PowerAndArmor__/graphics/icons/steel-drill.png",
			flags = {"goes-to-main-inventory"},
			action =
			{
				type="direct",
				action_delivery =
				{	
					type = "instant",
					target_effects =
					{
						type = "damage",
						damage = { amount = 16 , type = "physical"}
					}
				}
			},
			durability = 10000,
			subgroup = "tool",
			order = "a[mining]-b[steel-drill]",
			speed = 8,
			stack_size = 20
		},
		{
			type = "mining-tool",
			name = "alien-steel-drill",
			icon = "__PowerAndArmor__/graphics/icons/alien-steel-drill.png",
			flags = {"goes-to-main-inventory"},
			action =
			{
				type="direct",
				action_delivery =
				{
					type = "instant",
					target_effects =
					{
						type = "damage",
						damage = { amount = 32 , type = "physical"}
					}
				}
			},
			durability = 20000,
			subgroup = "tool",
			order = "a[mining]-c[alien-steel-drill]",
			speed = 16,
			stack_size = 20
		}
	})
end 
 --power
 if add_entities then
	data:extend(
	{
		{
			type = "item",
			name = "supercharged-medium-electric-pole",
			icon = "__PowerAndArmor__/graphics/icons/supercharged-medium-electric-pole.png",
			flags = {"goes-to-quickbar"},
			subgroup = "energy-pipe-distribution",
			order = "a[energy]-b[medium-electric-pole]",
			place_result = "supercharged-medium-electric-pole",
			stack_size = 50
		},
		{
			type = "item",
			name = "supercharged-substation",
			icon = "__PowerAndArmor__/graphics/icons/supercharged-substation.png",
			flags = {"goes-to-quickbar"},
			subgroup = "energy-pipe-distribution",
			order = "a[energy]-d[substation]",
			place_result = "supercharged-substation",
			stack_size = 50
		},
	})
end