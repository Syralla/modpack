data:extend(
{
	{
		type = "night-vision-equipment",
		name = "night-vision-equipment-mk2",
		sprite =
		{
			filename = "__PowerAndArmor__/graphics/equipment/night-vision-equipment-mk2.png",
			width = 96,
			height = 64,
			priority = "medium"
		},
		shape =
		{
			width = 3,
			height = 2,
			type = "full"
		},
		categories = {"armor"},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "12kJ",
			input_flow_limit = "24kW",
			usage_priority = "primary-input"
		},
		energy_input = "1kW",
		tint = {r = 0, g = 0, b = 0, a = 0.2}
	},
	{
		type = "generator-equipment",
		name = "fusion-reactor-equipment-mk2",
		sprite =
		{
			filename = "__PowerAndArmor__/graphics/equipment/fusion-reactor-equipment-mk2.png",
			width = 128,
			height = 128,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 4,
			height = 4,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "primary-output"
		},
		power = "3MW"
	},
	
	{
		type = "movement-bonus-equipment",
		name = "exoskeleton-equipment-mk2",
		sprite =
		{
			filename = "__PowerAndArmor__/graphics/equipment/exoskeleton-equipment-mk2.png",
			width = 64,
			height = 128,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 2,
			height = 4,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			usage_priority = "secondary-input"
		},
		energy_consumption = "30kW",
		movement_bonus = 0.6
	},
	{
		type = "roboport-equipment",
		name = "personal-roboport-equipment-mk2",
		take_result = "personal-roboport-equipment-mk2",
		sprite =
		{
			filename = "__PowerAndArmor__/graphics/equipment/personal-roboport-equipment-mk2.png",
			width = 64,
			height = 64,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 2,
			height = 2,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "70MJ",
			input_flow_limit = "7MW",
			usage_priority = "secondary-input"
		},
		charging_energy = "2MW",
		energy_consumption = "200kW",

		robot_limit = 20,
		construction_radius = 30,
		spawn_and_station_height = 0.4,
		charge_approach_distance = 2.6,

		radius_visualisation_picture =
		{
			filename = "__base__/graphics/entity/roboport/roboport-radius-visualization.png",
			width = 12,
			height = 12
		},
		construction_radius_visualisation_picture =
		{
			filename = "__base__/graphics/entity/roboport/roboport-construction-radius-visualization.png",
			width = 12,
			height = 12
		},

		recharging_animation =
		{
			filename = "__base__/graphics/entity/roboport/roboport-recharging.png",
			priority = "high",
			width = 37,
			height = 35,
			frame_count = 16,
			scale = 1.5,
			animation_speed = 0.5
		},
		recharging_light = {intensity = 0.4, size = 5},
		stationing_offset = {0, -0.6},
		charging_station_shift = {0, 0.5},
		charging_station_count = 4,
		charging_distance = 1.6,
		charging_threshold_distance = 5
	},
	{
		type = "energy-shield-equipment",
		name = "energy-shield-mk3-equipment",
		sprite =
		{
			filename = "__PowerAndArmor__/graphics/equipment/energy-shield-mk3-equipment.png",
			width = 64,
			height = 64,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 2,
			height = 2,
			type = "full"
		},
		max_shield_value = 300,
		energy_source =
		{
			type = "electric",
			buffer_capacity = "36kJ",
			input_flow_limit = "72kW",
			usage_priority = "primary-input"
		},
		energy_per_shield = "3kJ"
	},
	{
		type = "active-defense-equipment",
		name = "personal-laser-defense-equipment-mk2",
		sprite =
    {
		filename = "__PowerAndArmor__/graphics/equipment/personal-laser-defense-equipment-mk2.png",
		width = 64,
		height = 96,
		priority = "medium"
    },
	categories = {"armor"},
	shape =
    {
		width = 2,
		height = 3,
		type = "full"
    },
	energy_source =
    {
		type = "electric",
		usage_priority = "secondary-input",
		buffer_capacity = "200kJ"
    },
    attack_parameters =
    {
		type = "projectile",
		ammo_category = "electric",
		cooldown = 20,
		damage_modifier = 2,
		projectile_center = {0, 0},
		projectile_creation_distance = 0.6,
		range = 20,
		sound = make_laser_sounds(),
		ammo_type =
		{
			type = "projectile",
			category = "electric",
			energy_consumption = "150kJ",
			projectile = "laser",
			speed = 1,
			action =
			{
				{
					type = "direct",
					action_delivery =
					{
						{
							type = "projectile",
							projectile = "laser",
							starting_speed = 0.28
						}
					}
				}
			}
		}
	},
	automatic = true
	},
	{
		type = "battery-equipment",
		name = "battery-equipment-mk3",
		sprite =
		{
			filename = "__PowerAndArmor__/graphics/equipment/battery-equipment-mk3.png",
			width = 32,
			height = 64,
			priority = "medium"
		},
		categories = {"armor"},
		shape =
		{
			width = 1,
			height = 2,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "2GJ",
			input_flow_limit = "40GW",
			output_flow_limit = "40GW",
			usage_priority = "terciary"
		}
	},
})