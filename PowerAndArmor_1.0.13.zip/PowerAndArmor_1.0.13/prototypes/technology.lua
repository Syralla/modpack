--armor technologies
data:extend(
{
	{
		type = "technology",
		name = "armor-upgrades",
		icon = "__PowerAndArmor__/graphics/technology/power-armor-mk3.png",
		icon_size = 128,
		prerequisites = {"power-armor-2", "productivity-module-3", "effectivity-module-3", "speed-module-3"},
		unit =
		{
			count = 250,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
        time = 20,
		},
		order = "g-c-c",
	},
	{
		type = "technology",
		name = "mk3-power-armor",
		icon = "__PowerAndArmor__/graphics/technology/power-armor-mk3.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "power-armor-mk3",
			},
			{
				type = "unlock-recipe",
				recipe = "power-armor-mk2-upgrade",
			}
			
		},
		prerequisites = {"armor-upgrades"},
		unit =
		{
			count = 100,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-d",
	},
})
table.insert(data.raw["technology"]["power-armor"].effects, {type = "unlock-recipe", recipe = "modular-armor-upgrade"})
table.insert(data.raw["technology"]["power-armor-2"].effects, {type = "unlock-recipe",recipe = "power-armor-upgrade"})
	
-- equipment technologies
data:extend(
{ 
	{
		type = "technology",
		name = "mk2-fusion-reactor-equipment",
		icon = "__PowerAndArmor__/graphics/technology/fusion-reactor-equipment-mk2.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "fusion-reactor-equipment-mk2",
			},
		},
		prerequisites = {"armor-upgrades", "fusion-reactor-equipment"},
		unit =
		{
			count = 100,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-e",
	},
	{
		type = "technology",
		name = "mk2-exoskeleton-equipment",
		icon = "__PowerAndArmor__/graphics/technology/exoskeleton-equipment-mk2.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "exoskeleton-equipment-mk2"
			},
		},
		prerequisites = {"armor-upgrades", "exoskeleton-equipment"},
		unit =
		{
			count = 50,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-f",
	},
	{
		type = "technology",
		name = "mk2-night-vision-equipment",
		icon = "__PowerAndArmor__/graphics/technology/night-vision-equipment-mk2.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "night-vision-equipment-mk2"
			},
		},
		prerequisites = {"armor-upgrades", "night-vision-equipment"},
		unit =
		{
			count = 50,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-g",
	},
	{
		type = "technology",
		name = "mk2-personal-roboport-equipment",
		icon = "__PowerAndArmor__/graphics/technology/personal-roboport-equipment-mk2.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "personal-roboport-equipment-mk2"
			},
		},
		prerequisites = {"armor-upgrades", "personal-roboport-equipment"},
		unit =
		{
			count = 75,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-h",
	},
	{
		type = "technology",
		name = "mk3-energy-shield-equipment",
		icon = "__PowerAndArmor__/graphics/technology/energy-shield-equipment-mk3.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "energy-shield-mk3-equipment"
			},
		},
		prerequisites = {"armor-upgrades", "energy-shield-mk2-equipment"},
		unit =
		{
			count = 50,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-i",
	},
	{
		type = "technology",
		name = "mk3-battery-equipment",
		icon = "__PowerAndArmor__/graphics/technology/battery-equipment-mk3.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "battery-equipment-mk3"
			},
		},
		prerequisites = {"armor-upgrades", "battery-mk2-equipment"},
		unit =
		{
			count = 50,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-j",
	},
	{
		type = "technology",
		name = "mk2-personal-laser-defense-equipment",
		icon = "__PowerAndArmor__/graphics/technology/personal-laser-defense-equipment-mk2.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "personal-laser-defense-equipment-mk2"
			},
		},
		prerequisites = {"armor-upgrades", "personal-laser-defense-equipment"},
		unit =
		{
			count = 50,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1},
				{"alien-science-pack", 1}
			},
			time = 10,
		},
		order = "g-c-k",
	},
})

--tool technologies
if add_tools then
	data:extend(
	{
		{
			type = "technology",
			name = "steel-drill",
			icon = "__PowerAndArmor__/graphics/technology/steel-drill.png",
			icon_size = 128,
			effects =
			{
				{
					type = "unlock-recipe",
					recipe = "steel-drill"
				},
			},
			prerequisites = {"electric-engine"},
			unit =
			{
				count = 50,
				ingredients =
				{
					{"science-pack-1", 1},
					{"science-pack-2", 1},
				},
				time = 10,
			},
			order = "g-c-j",
		},
		{
			type = "technology",
			name = "alien-steel-drill",
			icon = "__PowerAndArmor__/graphics/technology/alien-steel-drill.png",
			icon_size = 128,
			effects =
			{
				{
					type = "unlock-recipe",
					recipe = "alien-steel-drill"
				},
			},
			prerequisites = {"steel-drill", "alien-technology"},
			unit =
			{
				count = 25,
				ingredients =
				{
					{"science-pack-1", 2},
					{"science-pack-2", 2},
					{"alien-science-pack", 1}
				},
				time = 10,
			},
			order = "g-c-k",
		},
	})
end
--vanilla technologies
data:extend(
{	
	{
		type = "technology",
		name = "railgun",
		icon = "__base__/graphics/icons/railgun.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "railgun"
			},
			{
				type = "unlock-recipe",
			recipe = "railgun-dart"
			}
		},
		prerequisites = {"military-3"},
		unit =
		{
			count = 50,
			ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 10,
		},
		order = "g-c-j",
	},
})
--power technologies
if add_entities then
	data:extend({
		{
			type = "technology",
			name = "electric-energy-distribution-3",
			icon = "__base__/graphics/technology/electric-energy-distribution.png",
			effects =
			{
				{
					type = "unlock-recipe",
					recipe = "supercharged-medium-electric-pole"
				},
				{
					type = "unlock-recipe",
					recipe = "supercharged-substation"
				}
			},
			prerequisites = {"electric-energy-distribution-2"},
			unit =
			{
				count = 100,
				ingredients =
			{
				{"science-pack-1", 1},
				{"science-pack-2", 1},
				{"science-pack-3", 1}
			},
			time = 45
			},
			order = "c-e-c",
		},
	})
end	