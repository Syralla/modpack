if not autodeconstruct then autodeconstruct = {} end

autodeconstruct.remove_target = true

 --[[
    To toggle debug messages
    /c remote.call("ad", "debug")
    
    To call init
    /c remote.call("ad", "init")
 --]] 
