for i, obj in pairs(data.raw["car"]) do
  if obj.equipment_grid == nil then
    obj.equipment_grid = "large-equipment-grid"
  end
end
for i, obj in pairs(data.raw["locomotive"]) do
  if obj.equipment_grid == nil then
    obj.equipment_grid = "large-equipment-grid"
  end
end
for i, obj in pairs(data.raw["cargo-wagon"]) do
  if obj.equipment_grid == nil then
    obj.equipment_grid = "large-equipment-grid"
  end
end
