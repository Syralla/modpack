--A lot of Thanks to iUltimateLP and his mod SimpleTeleporters for inspiration and for the use of His Code and graphics


require("prototypes.recipe")
require("prototypes.item")
require("prototypes.entity")
require("prototypes.technology")
require("prototypes.teleporter-tiers")
require("prototypes.equipment")
require("prototypes.style")