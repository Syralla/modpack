turret_y_offset = 0.1
programmable_identifier = "programmable"
composite_suffix = "-_-" -- used to filter out sub-units (i.e. "-" would break most units)
damage_target_max_health = 1000000
