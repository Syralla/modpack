-- constants
local version = 000110 -- 0.1.10
local turret_y_offset = 0.1
local programmable_identifier = "programmable"
local composite_suffix = "-_-" -- used to filter out sub-units (i.e. "-" would break most units)
local damage_target_max_health = 1000000
local starting_items = {{name = "unit-remote-control", count = 1}}
local unit_target_search_interval = 60
local vehicle_acceleration_multiplier = math.sqrt(10/3)/600 -- 0.003042903097
local navigator_minimum_range = 4.5

local util = require("util") -- keep seperate for sharing

-- locals
local min = util.min
local max = util.max
local floor = util.floor
local abs = util.abs
local sqrt = util.sqrt
local sin = util.sin
local cos = util.cos
local atan = util.atan
local pi = util.pi
local remove = util.remove
local insert = util.insert
local str_sub = util.str_sub
local str_gsub = util.str_gsub
local send_message = util.send_message
local remove_from_table = util.remove_from_table
local transfer_inventory = util.transfer_inventory
local transfer_inventory_filters = util.transfer_inventory_filters
local transfer_equipment_grid = util.transfer_equipment_grid
local position_to_xy_string = util.position_to_xy_string
local xy_to_string = util.xy_to_string
local lerp_angles = util.lerp_angles
local array_to_vector = util.array_to_vector
local vectors_delta = util.vectors_delta
local vectors_delta_length = util.vectors_delta_length
local vector_length = util.vector_length
local vector_length_xy = util.vector_length_xy
local vector_dot = util.vector_dot
local vector_dot_projection = util.vector_dot_projection
local vector_normalise = util.vector_normalise
local orientation_from_to = util.orientation_from_to
local orientation_to_vector = util.orientation_to_vector
local vectors_add = util.vectors_add
local lerp_vectors = util.lerp_vectors
local move_to = util.move_to
local vector_to_orientation = util.vector_to_orientation
local vector_to_orientation_xy = util.vector_to_orientation_xy
local direction_to_orientation = util.direction_to_orientation
local signal_to_string = util.signal_to_string
local signal_container_add_inventory = util.signal_container_add_inventory
local signal_container_add = util.signal_container_add
local signal_container_get = util.signal_container_get
local char_to_multiplier = util.char_to_multiplier
local string_to_number = util.string_to_number
local replace = util.replace

--[[
CUSTOM EVENTS SENT

on_entity_replaced
raise_event implementation: raise_event('on_entity_revived', {new_entity = LuaEntity, new_entity_unit_number = uint, old_entity = LuaEntity?, old_entity_unit_number = uint}) 
on_event implementation: remote.add_interface("mymod", { on_entity_replaced = function(data) return myfunction(data.new_entity, data.new_entity_unit_number, ...) end})

]]--
local function raise_event(event_name, event_data) 
	local responses = {}
	for interface_name, interface_functions in pairs(remote.interfaces) do
		if interface_functions[event_name] then
			responses[interface_name] = remote.call(interface_name, event_name, event_data)
		end
	end
	return responses
end


-- control-unit-unit_type

local function unit_template()
	return {
		unit_id = 0, -- Uint, static
		unit_type = "type-name", -- String
		unit_type_id = 0, -- index within unit_type array, dynamic
		mode = "vehicle", -- String: drive, vehicle, unit
		vehicle_whole = nil, -- Entity
		vehicle_solid = nil, -- Entity
		vehicle_ghost = nil, -- Entity
		navigator = nil, -- Entity
		turret = nil, -- Entity
		position_last = nil, -- Position
		position = nil, -- Position
		speed = 0, -- Float
		health = 0, -- Float
		energy = 0, -- Float 
			-- internal energy stored after consuming a unit of fuel or being charged. burn from fuel can exceed capacity.
			-- use vehicles actual energy as a buffer. try to prevent the actual vehicle from consuming fuel
		weapon = nil, -- see unit_load_ammo()
			--	a loaded packaged weapon with ammo type, attacks stats, multipliers, rounds left, etc. 
			-- updated on fire and loading new ammo
		data = {}, -- counts for various types of signal data stores as [type][name] = {signal = signal, count = count}
			-- use signal_container_add and signal_container_get
			-- should be the same format as structure inputs and outputs
		target_angle = nil,  -- Float
		target_speed = 0, -- Float
		target_position = nil, -- Position (as ints for tile) -- used for move_to, prevents constant commands to same tile
		attack_target = nil, -- Entity
		attack_last_tick = 0, -- Uint
		target_last_tick = 0, -- Uint
		order_last_tick = 0, -- Uint
		move_last_tick = 0, -- Uint
		move_to_last_tick = 0, -- Uint
	}
end

local function unit_setup_vehicle(vehicle)
	local unit_type = {
		name = vehicle.name,
		vehicle_whole = vehicle.name,
		vehicle_whole_prototype = vehicle,
		vehicle_solid = vehicle.name .. composite_suffix .. "solid",
		vehicle_ghost = vehicle.name .. composite_suffix .. "ghost",
		navigator = vehicle.name .. composite_suffix .. "navigator",
		damage_target = vehicle.name .. composite_suffix .. "damage_target",
		buffer = vehicle.name .. composite_suffix .. "buffer",
		lamp = vehicle.name .. composite_suffix .. "lamp",
		lamp_sound = vehicle.name .. composite_suffix .. "lamp_sound",
		--signal = {type = "item", name = vehicle.minable.result},
		signal = {type = "virtual", name = vehicle.name .. composite_suffix .. "signal"},
		effectivity = vehicle.effectivity or 1,
		acceleration = math.sqrt(string_to_number(vehicle.consumption) * vehicle.effectivity / vehicle.weight) * vehicle_acceleration_multiplier,
		friction = vehicle.friction,
		weight = vehicle.weight,
		rotation_speed = vehicle.rotation_speed,
		energy_capacity = string_to_number(vehicle.consumption) * 60,
		collides_with_ground = false, 
		is_flying = false,
		radius = math.max(-vehicle.collision_box[1][1], -vehicle.collision_box[1][2], vehicle.collision_box[2][1], vehicle.collision_box[2][2]),
	}
	unit_type.brake = math.max(unit_type.acceleration, math.sqrt(string_to_number(vehicle.braking_power) / vehicle.weight) * vehicle_acceleration_multiplier) -- note: effectivity does not affect brake, only consumption
	unit_type.brake = 120000
	if vehicle.collision_mask then
		local is_flying = true
		for _, layer in pairs(vehicle.collision_mask) do 
			if layer == 'ground-tile' then
				unit_type.collides_with_ground = true
			end
			if layer ~= 'ghost-layer' then
				is_flying = false
			end
		end
		if is_flying then 
			unit_type.is_flying = true
		end
	end
	if not (vehicle.tank_driving and vehicle.tank_driving == true) then
		unit_type.rotation_speed = unit_type.rotation_speed / 2
	end
	if vehicle.turret_animation and vehicle.turret_animation.layers 
		and game.entity_prototypes[vehicle.name .. composite_suffix .. "turret"] then 
		unit_type.turret = vehicle.name .. composite_suffix .. "turret"
		unit_type.turret_rotation_speed = vehicle.turret_rotation_speed
	end
	
	-- prompt any required ammo categories for inflation
	if vehicle.guns then 
		unit_type.gun = remote.call("data-raw", "prototype", "gun", vehicle.guns[1])
	end

	global.unit_types[unit_type.name] = unit_type
	global.unit_types_by_signal[signal_to_string(unit_type.signal)] = unit_type
end

local function unit_load_prototypes()
	
	if global.prototypes_require_load == false then return end -- already loaded
	
	if remote.call("data-raw", "prototypes_list") then
		-- prototypes are loadable, clear old data
		global.unit_types = {}
		global.unit_types_by_signal = {}
		global.unit_mineable_resources =  {}
		
		for _,vehicle_name in pairs(remote.call("data-raw", "prototypes_list").car) do 
			if not string.find(vehicle_name, composite_suffix, 1, true) then -- exclude attachments
				local vehicle = remote.call("data-raw", "prototype", "car", vehicle_name)
				if vehicle.order then 
					if string.find(vehicle.order, programmable_identifier, 1, true) then 
						unit_setup_vehicle(vehicle)
					end
				end
			end
		end
		
		for _,resource_name in pairs(remote.call("data-raw", "prototypes_list").resource) do 
			local resource = game.entity_prototypes[resource_name]
			if resource and resource.mineable_properties and resource.mineable_properties.products then
				for _2, product in pairs(resource.mineable_properties.products) do 
					if product.type == "item" then
						global.unit_mineable_resources[product.name] = product.name
					end
				end
			end
		end
		
		global.prototypes_require_load = false
	end
	
end

local function unit_setup_unit_types() -- depreciated
	unit_load_prototypes()
end

local function unit_get_type(unit)
	if global.prototypes_require_load ~= false then 
		unit_load_prototypes() 
	end
	return global.unit_types[unit.unit_type]
end


local function unit_on_destroy_entity(entity)
	if entity.valid and entity.unit_number then
		global.unit.unit_numbers[entity.unit_number] = nil
	end
end

local function destroy_entity(entity)
	if entity.valid then
		unit_on_destroy_entity(entity)
		entity.destroy()
	end
	return nil
end

local function unit_find_from_entity(entity)
	local unit_id = global.unit.unit_numbers[entity.unit_number]
	if unit_id then
		return global.unit.units[unit_id]
	end
	return nil
end

local function unit_loop_index(unit_type, index)
	if global.unit.unit_types[unit_type] then
		if index > 0 then
			index = (index-1) % #global.unit.unit_types[unit_type] +1
		else -- reverse if negative
			index = (#global.unit.unit_types[unit_type] + index) % #global.unit.unit_types[unit_type] + 1
		end
		return index
	end
end

local function unit_by_type_and_index(unit_type, index)
	if global.unit.unit_types[unit_type] and #global.unit.unit_types[unit_type] > 0 then
		--index = unit_loop_index(unit_type, index)
		if index > 0 and index <= #global.unit.unit_types[unit_type] then
			return global.unit.unit_types[unit_type][index]
		elseif index < 0 and -index <= #global.unit.unit_types[unit_type] then
			return global.unit.unit_types[unit_type][#global.unit.unit_types[unit_type] + index + 1]
		end
	end
end

local function unit_find_from_signal(data)
	--data = {signal = SignalID, count = count} returns unit
	signal_count = data
	if signal_count and signal_count.signal and signal_count.count then
		if signal_count.signal.name == "signal-id" then 
			local unit = global.unit.units[signal_count.count]
			if unit and unit.vehicle and unit.vehicle.valid then 
				unit.unit_type_snapshot = unit_get_type(unit)
				return unit
			end
		else
			local unit_type = global.unit_types_by_signal[signal_to_string(signal_count.signal)]
			if unit_type then
				local unit = unit_by_type_and_index(unit_type.name, signal_count.count)
				if unit and unit.vehicle and unit.vehicle.valid then 
					unit.unit_type_snapshot = unit_get_type(unit)
					return unit
				end
			end
		end
	end
end


local function unit_get_count_by_type(unit_type)
	if global.unit.unit_types[unit_type] then 
		return #global.unit.unit_types[unit_type]
	end
end

local function unit_set_data(data)
	local unit_id = data.unit_id
	local signal_data = data.data or {}
	if unit_id and global.unit.units[unit_id] and global.unit.units[unit_id].vehicle 
	and global.unit.units[unit_id].vehicle.valid then
		global.unit.units[unit_id].data = signal_data
	end
end


local function unit_check_navigator_stop(unit, target_position,  distance_to_target)
	return unit.energy <= 0 or target_position == nil or distance_to_target < navigator_minimum_range or (unit.navigator and unit.navigator.has_command() == false)
end

local function unit_nudge_entity(unit, entity)
	local target = entity
	if target.valid then
		local save_pos = target.position
		target.teleport({x = save_pos.x, y = save_pos.y + 10}) -- move out of the way
		local safe = target.surface.find_non_colliding_position(unit_get_type(unit).buffer, save_pos, 3, 0.1)
		if safe then
			target.teleport(lerp_vectors(save_pos, safe, 0.05))
		else
			target.teleport(save_pos)
		end
	end
end

local function unit_nudge(unit)
	unit_nudge_entity(unit, unit.vehicle)
	if(unit.navigator and unit.navigator.valid) then 
		unit_nudge_entity(unit, unit.navigator)
	end
	unit.safe_target_position = nil
end

local function unit_rotate_to_angle(target, angle, rotation_speed, turn_slows)
	if not rotation_speed then return end
	local da = angle - target.orientation
	if da < -0.5 then
		da = da + 1
	elseif da > 0.5 then
		da = da - 1
	end
	da = util.max(util.min(da, rotation_speed), - rotation_speed)
	target.orientation = target.orientation + da
	if(turn_slows) then
		target.speed = target.speed * (1 - util.abs(da)*5)
	end
end

local function unit_delta_angle(angle, target_angle)
	local da = target_angle - angle
	if da < -0.5 then
		da = da + 1
	elseif da > 0.5 then
		da = da - 1
	end
	return da
end

local function unit_delta_angle_abs(angle, target_angle)
	local da = target_angle - angle
	if da < -0.5 then
		da = da + 1
	elseif da > 0.5 then
		da = da - 1
	end
	return util.abs(da)
end

local function unit_rotate_to_target_angle(unit)
	if unit.target_angle ~= nil then
		local da = unit.target_angle - unit.vehicle.orientation
		if da < -0.5 then
			da = da + 1
		elseif da > 0.5 then
			da = da - 1
		end
		da = math.max(math.min(da, unit_get_type(unit).rotation_speed), - unit_get_type(unit).rotation_speed)
		unit.vehicle.orientation = unit.vehicle.orientation + da
		unit.vehicle.speed = unit.vehicle.speed * (1 - math.abs(da)*2)
	end
end

local function unit_force_for_speed(base_force, speed)
	-- forces are reduced at high speed
	return (((speed / base_force)^2+1)^0.5-(speed / base_force)) * base_force
end

local function unit_speed_to(unit, target_speed)
	local target_speed_change = target_speed - unit.vehicle.speed
	local unit_type = unit_get_type(unit)
	local force = 0
	if target_speed_change > 0 then
		force = unit_force_for_speed(unit_type.acceleration, math.abs(unit.vehicle.speed))
		force = math.min(target_speed_change, force, 0.01) -- cap acceleration
		unit.vehicle.speed = unit.vehicle.speed + force
	elseif target_speed_change < 0 then
		force = unit_force_for_speed(unit_type.brake, math.abs(unit.vehicle.speed))
		force = math.min(-target_speed_change, force)
		unit.vehicle.speed = unit.vehicle.speed - force
	end
end

local function unit_speed_to_target_speed(unit)
	if unit.target_speed ~= nil then
		unit_speed_to(unit, unit.target_speed)
	end
end

local function update_unit_type_ids(unit_type)
	for i, unit in ipairs(global.unit.unit_types[unit_type]) do 
		unit.unit_type_id = i
	end
end

local function update_unit_types_ids()
	for unit_type_name, list in pairs(global.unit.unit_types) do 
		update_unit_type_ids(unit_type_name)
	end
end	

local function unit_manage_new(entity, signals) 
	local existing_unit = unit_find_from_entity(entity)
	if existing_unit then return end -- unit already is managed
	unit_load_prototypes() 
	for _, unit_type in pairs(global.unit_types) do 
		if entity.name == unit_type.vehicle_whole or entity.name == unit_type.vehicle_solid or entity.name == unit_type.vehicle_ghost then
			local unit_id = global.unit.next_unit_id
			global.unit.next_unit_id = global.unit.next_unit_id + 1
			
			-- make new unit from template
			local unit = unit_template()
			unit.unit_id = unit_id
			unit.unit_type = unit_type.name
			unit.position_last = entity.position
			unit.position = entity.position
			unit.energy = unit_type.energy_capacity/60
			unit.vehicle = entity
			
			unit.attack_last_tick = global.tick
			unit.target_last_tick = global.tick
			unit.order_last_tick = global.tick
			unit.move_last_tick = global.tick
			unit.move_to_last_tick = global.tick
			
			local data = unit.data
			if string.find(unit_type.name, "vehicle-miner", 1, true) then
			--if unit_type.name == "vehicle-miner" then
				for _2, resource in pairs(global.unit_mineable_resources) do 
					if resource ~= "raw-wood" and resource ~= "coal" then
						signal_container_add(data, {type = "item", name=resource}, -1)
					end
				end
				signal_container_add(data, {type = "item", name="raw-wood"}, 50)
				signal_container_add(data, {type = "item", name="coal"}, 100)
			elseif unit_type.name == "vehicle-hauler" then
				for _2, resource in pairs(global.unit_mineable_resources) do 
					signal_container_add(data, {type = "item", name=resource}, 12000)
				end
				signal_container_add(data, {type = "item", name="raw-wood"}, 12000)
			else 
				signal_container_add(data, {type = "item", name="coal"}, 50)
			end
			
			if signals then 
				local signals_valid = false
				
				for signal_type, signals in pairs(unit.data) do
					for signal_name, signal_count in pairs(signals) do
						if signal_name ~= unit_type.name then
							signals_valid = true
							break
						end
					end
				end
				-- it is at least not nil not empty and no only containing deployer contents
				if signals_valid then 
					unit.data = signals 
				end
			end
			
			global.unit.units[unit_id] = unit
			global.unit.unit_numbers[entity.unit_number] = unit_id
			table.insert(global.unit.unit_types[unit.unit_type], unit)
			update_unit_type_ids(unit.unit_type)
			if global.unit.entities_pending_manage then 
				global.unit.entities_pending_manage[entity.unit_number] = nil
			end
		end
	end
end


local function unit_cleanup_entities_manage_if_found(search_type) 
	for _, surface in pairs(game.surfaces) do 
		local entities = surface.find_entities_filtered{name=search_type}
		for _, entity in pairs(entities) do 
			unit_manage_new(entity) 
		end
	end
end

local function unit_cleanup_entities_delete_if_found(search_type) 
	for _, surface in pairs(game.surfaces) do 
		local entities = surface.find_entities_filtered{name=search_type}
		for _, entity in pairs(entities) do 
			local existing_unit = unit_find_from_entity(entity)
			if not (existing_unit and existing_unit.mode ~= "removed" and existing_unit.vehicle and existing_unit.vehicle.valid) then 
				entity.destroy()
			end
		end
	end
end

local function unit_cleanup_entities() 

	unit_load_prototypes() 
	for _, unit_type in pairs(unit_types) do 
		unit_cleanup_entities_delete_if_found(unit_type.navigator)
		unit_cleanup_entities_delete_if_found(unit_type.damage_target)
		unit_cleanup_entities_delete_if_found(unit_type.buffer)
		unit_cleanup_entities_delete_if_found(unit_type.lamp)
		unit_cleanup_entities_delete_if_found(unit_type.lamp_sound)
		if unit_type.turret then unit_cleanup_entities_delete_if_found(unit_type.turret) end
		unit_cleanup_entities_manage_if_found(unit_type.vehicle_solid)
		unit_cleanup_entities_manage_if_found(unit_type.vehicle_whole)
		unit_cleanup_entities_manage_if_found(unit_type.vehicle_ghost)
	end
end

	

local function unit_unmanage(unit)
	if unit then
		if unit.vehicle and unit.vehicle.valid then
			unit_on_destroy_entity(unit.vehicle)
			unit.vehicle.die()
			unit.vehicle = nil
		end
		if unit.navigator then
			unit.navigator = destroy_entity(unit.navigator)
		end
		if unit.damage_target then
			unit.damage_target = destroy_entity(unit.damage_target)
		end
		if unit.turret then
			unit.turret = destroy_entity(unit.turret)
		end
		if unit.attachment then
			unit.attachment = destroy_entity(unit.attachment)
		end
		if unit.lamp then
			unit.lamp = destroy_entity(unit.lamp)
		end
		if unit.lamp_sound then
			unit.lamp_sound = destroy_entity(unit.lamp_sound)
		end
		global.unit.units[unit.unit_id] = nil
		-- remove from unit type index
		local remove_index = 0
		for i, comp_unit in ipairs(global.unit.unit_types[unit.unit_type]) do
			if comp_unit == unit then
				remove_index = i
				break
			end
		end
		if remove_index > 0 then
			table.remove(global.unit.unit_types[unit.unit_type], remove_index)
			update_unit_type_ids(unit.unit_type)
		end
		unit.mode = "removed"
	end
end

local function unit_unmanage_by_entity(entity) 
	local unit = unit_find_from_entity(entity)
	unit_unmanage(unit)
end

local function unit_on_entity_died(event)
	unit_unmanage_by_entity(event.entity)
end

local function unit_create_entity(unit, entity_type, surface, position, force)
	local entity = surface.create_entity{name=entity_type, position=position, force=force}
	if entity.unit_number then 
		global.unit.unit_numbers[entity.unit_number] = unit.unit_id
	end
	return entity
end

local function unit_create_entity_from_entity(unit, entity_type, source_entity, replace)
	local source_entity_number = source_entity.unit_number
	local entity = unit_create_entity(unit, entity_type, source_entity.surface, source_entity.position, source_entity.force, replace)
	if source_entity.valid then
		entity.orientation = source_entity.orientation
		if replace then
			entity.health = source_entity.health
			entity.speed = source_entity.speed
			entity.energy = source_entity.energy
			transfer_inventory_filters(source_entity, entity, defines.inventory.car_trunk)
			transfer_inventory(source_entity, entity, defines.inventory.car_fuel)
			transfer_inventory(source_entity, entity, defines.inventory.car_trunk)
			transfer_inventory(source_entity, entity, defines.inventory.car_ammo)
			transfer_equipment_grid(source_entity, entity)
			raise_event("on_entity_replaced", 
				{	new_entity = entity, 
					new_entity_unit_number = entity.unit_number, 
					old_entity = source_entity, 
					old_entity_unit_number = source_entity.unit_number})
			destroy_entity(source_entity)
		end	
	else
		global.unit.unit_numbers[entity.unit_number] = nil
	end
	return entity
end

local function unit_navigate_to_target_position(unit)
	local distance_to_target = vectors_delta_length(unit.vehicle.position, unit.target_position)
	if unit.mode ~= "drive" and unit.navigator and unit.navigator.valid 
		and unit.target_position and distance_to_target > navigator_minimum_range
		and unit.energy > 0 then 
		unit_nudge(unit)
		local safe_position = unit.navigator.surface.find_non_colliding_position(
			unit_get_type(unit).navigator, -- name of type
			unit.target_position, -- position
			10, -- radius
			0.25 -- precision 
		)
		unit.navigator.set_command({
			type=defines.command.go_to_location, 
			destination= safe_position or unit.target_position, 
			distraction=defines.distraction.by_enemy})
		unit.min_distance_to_target = distance_to_target
		unit.move_to_last_tick = global.tick
	end
end

local function unit_set_target_position(unit, position)
	unit.target_angle = nil
	unit.target_speed = 0
	if unit.target_position == nil or math.floor(unit.target_position.x) ~= math.floor(position.x) or math.floor(unit.target_position.y) ~= math.floor(position.y) then
		unit.target_position = position
		if unit.mode ~= "drive" and not unit_check_navigator_stop(unit, position, vectors_delta_length(unit.vehicle.position, position)) then
			unit.mode = "unit"
			unit_navigate_to_target_position(unit)
		elseif vectors_delta_length(unit.vehicle.position, position) > 0.25 then
			unit.mode = "vehicle_move_to"
		end
	else
		-- will not affect pathfinding, just update subtile change if any
		unit.target_position = position
	end
end

local function unit_update_mode(unit) 
	-- this will complete any mode changes, it will not update things like last position
	local unit_type = unit_get_type(unit)
	if not (unit.vehicle and unit.vehicle.valid) then -- cannot return from loss of vehicle
		unit_unmanage(unit)
		return
	end
	if (unit_type.collides_with_ground or unit_type.is_flying) and unit.mode == "unit" then 
		unit.mode = "vehicle_move_to" -- navigator won't work in water
	end
	if unit.mode == "drive" then
		if unit.vehicle.name ~= unit_type.vehicle_whole then
			unit.vehicle = unit_create_entity_from_entity(unit, unit_type.vehicle_whole, unit.vehicle, true)
		end
		if unit.navigator then 
			unit.navigator = destroy_entity(unit.navigator)
		end
		if unit.damage_target then 
			unit.damage_target = destroy_entity(unit.damage_target)
		end
		if unit.turret then 
			unit.turret = destroy_entity(unit.turret)
		end
	elseif unit.mode == "vehicle" or unit.mode == "vehicle_move_to" then
		if unit.vehicle.name ~= unit_type.vehicle_solid then
			unit.vehicle = unit_create_entity_from_entity(unit, unit_type.vehicle_solid, unit.vehicle, true)
		end
		if not (unit.turret and unit.turret.valid) and unit_type.turret then
			unit.turret = unit_create_entity_from_entity(unit, unit_type.turret, unit.vehicle, false )
			unit.turret.destructible = false
			unit.turret.operable = false
			unit.turret.active = false
			unit.turret.energy = 10000
		end
		if unit.navigator then 
			unit.navigator = destroy_entity(unit.navigator)
		end
		if not (unit.damage_target and unit.damage_target.valid) then
			unit.damage_target = unit_create_entity_from_entity(unit, unit_type.damage_target, unit.vehicle, false )
		end
	elseif unit.mode == "unit" then
		if unit.vehicle.name ~= unit_type.vehicle_ghost then
			unit.vehicle = unit_create_entity_from_entity(unit, unit_type.vehicle_ghost, unit.vehicle, true)
		end
		if not (unit.turret and unit.turret.valid) and unit_type.turret then
			unit.turret = unit_create_entity_from_entity(unit, unit_type.turret, unit.vehicle, false )
			unit.turret.destructible = false
			unit.turret.operable = false
			unit.turret.active = false
			unit.turret.energy = 10000
		end
		if not (unit.navigator and unit.navigator.valid) then
			unit.navigator = unit_create_entity_from_entity(unit, unit_type.navigator, unit.vehicle, false )
			unit.navigator_last_position = unit.navigator.position
			unit.navigator.destructible = false
			unit_navigate_to_target_position(unit)
		end
		if not (unit.damage_target and unit.damage_target.valid) then
			unit.damage_target = unit_create_entity_from_entity(unit, unit_type.damage_target, unit.vehicle, false )
		end
	end
end


local function unit_consume_fuel_inventory (unit, inventory_def)
	local inventory = unit.vehicle.get_inventory(inventory_def)
	if inventory and not inventory.is_empty() then
		for fuel_name, count in pairs(inventory.get_contents()) do
			local item_type = game.item_prototypes[fuel_name]
			if item_type and item_type.fuel_value and item_type.fuel_value > 0 then
				unit.energy = unit.energy + item_type.fuel_value * 2 -- plug in effectivity
				inventory.remove({name=fuel_name, count=1})
				return true
			end
		end
	end
	return false
end

local function unit_consume_fuel (unit)
	local success = unit_consume_fuel_inventory(unit, defines.inventory.car_fuel)
	if not success then
		local success = unit_consume_fuel_inventory(unit, defines.inventory.car_trunk)
	end
end

local function unit_mining_particles(unit)
	if unit.attachment and unit.attachment.valid and unit.attachment.mining_target then
		local forward = orientation_to_vector(unit.vehicle.orientation, 1)
		if global.tick % 6 == 0 then -- smoke
			unit.vehicle.surface.create_entity{
				name = "smoke",
				position = vectors_add(unit.position, vectors_add({x=0, y=-0.4}, {x= forward.x * -0.25, y=forward.y * -0.25})),   
				source = unit.vehicle, 
				speed = 0.1,
				movement = {(math.random() - 0.5)*0.1, (math.random() - 0.5)*0.1},
				frame_speed = 1,
				vertical_speed = 0.1,
				height = 0.1} -- needs more testing
		end
		if global.tick % 3 == 0 and unit.attachment.mining_target.prototype.mineable_properties and
			unit.attachment.mining_target.prototype.mineable_properties.miningparticle then -- particle
			local height = math.random()
			local fm = 0.9 + math.random() * 0.1
			unit.vehicle.surface.create_entity{
				name = unit.attachment.mining_target.prototype.mineable_properties.miningparticle,
				position = vectors_add(unit.position, {x = (math.random() - 0.5) * 0.75 + fm * forward.x * 3, y = (math.random() - 0.5) * 0.75 +fm * forward.y * 3}),
				source = unit.vehicle, 
				speed = 0.1,
				movement = {(math.random() - 0.5)*0.15 + forward.x / 20, (math.random() - 0.5)*0.15 + forward.y / 20},
				frame_speed = 1,
				vertical_speed = height*0.1,
				height = height*0.1} -- needs more testing
		end
	end 
end

local function unit_on_damage_taken(unit)
	unit_nudge(unit)
end

--control-unit-combat
local function unit_load_ammo (unit) 
	if (unit.weapon and unit.weapon.rounds > 0) then 
		return
	end
	local unit_type = unit_get_type(unit)
	if unit_type.gun and unit_type.gun.attack_parameters and unit_type.gun.attack_parameters.ammo_category then 
		local ammo_category = unit_type.gun.attack_parameters.ammo_category
		
		local inventory = unit.vehicle.get_inventory(defines.inventory.car_ammo)
		if inventory and not inventory.is_empty() then
			for ammo_name, count in pairs(inventory.get_contents()) do
				local ammo = remote.call("data-raw", "prototype", "ammo", ammo_name)
				if ammo and ammo.ammo_type and ammo.ammo_type.category == ammo_category then
					unit.weapon = {
						ammo = ammo,
						rounds = ammo.magazine_size and ammo.magazine_size or 1
					}
					inventory.remove({name=ammo_name, count=1})
					return
				end
			end
		end
		
		local inventory = unit.vehicle.get_inventory(defines.inventory.car_trunk)
		if inventory and not inventory.is_empty() then
			for ammo_name, count in pairs(inventory.get_contents()) do
				local ammo = remote.call("data-raw", "prototype", "ammo", ammo_name)
				if ammo and ammo.ammo_type and ammo.ammo_type.category == ammo_category then
					unit.weapon = {
						ammo = ammo,
						rounds = ammo.magazine_size and ammo.magazine_size or 1
					}
					inventory.remove({name=ammo_name, count=1})
					return
				end
			end
		end
	end
	-- could not load
	unit.weapon = nil
end

local function unit_damage_target(unit, damage, damage_type)
	if(unit.attack_target and unit.attack_target.valid) then
		local multiplier = 1 + unit.turret.force.get_ammo_damage_modifier(unit.weapon.ammo.ammo_type.category)
		if unit_get_type(unit).gun.attack_parameters.damage_modifier then
			multiplier = multiplier * unit_get_type(unit).gun.attack_parameters.damage_modifier
		end
		unit.attack_target.damage(damage * multiplier, unit.turret.force, damage_type)
	end
end

local function unit_fire_target_effect(unit, effect, source_point, target_point)
	if effect.type == "damage" then
		if effect.damage.amount then
			unit_damage_target(unit, effect.damage.amount, effect.damage.type)
		else
			for _, damage in ipairs(effect.damage) do 
				unit_damage_target(unit, damage.amount, damage.type)
			end
		end
	else
		unit.turret.surface.create_entity{
			name = effect.entity_name,
			position = target_point,   
			source = unit.turret,
			target = target_point}
	end
end

local function unit_fire_source_effect(unit, effect, source_point, target_point)
	unit.turret.surface.create_entity{
		name = effect.entity_name,
		position = source_point,   
		source = unit.turret,
		target = target_point}
end

local function unit_fire_ammo_recursive(unit, current, source_point, target_point)
	if not current.type then -- array 
		for _, child in ipairs(current) do 
			unit_fire_ammo_recursive(unit, child, source_point, target_point)
		end
	else
		if current.action_delivery then 
			for i = 1, current.repeat_count and current.repeat_count or 1 do
				unit_fire_ammo_recursive(unit, current.action_delivery, source_point, target_point)
			end
		end
		if current.type == "projectile" then
			local projectile = remote.call("data-raw", "prototype", "projectile", current.projectile)
			if projectile and projectile.collision_box then
				-- this projectile can hit the vehicle.
				local extent = math.abs(projectile.collision_box[1][2])
				local radius = unit_get_type(unit).radius * 1.41 -- diagonal 
				unit.turret.surface.create_entity{
					name = current.projectile,
					position = move_to(unit.vehicle.position, target_point, extent + radius + 0.1, false ),   
					source = unit.vehicle,
					target = unit.attack_target, 
					speed = current.starting_speed}
			else
				unit.turret.surface.create_entity{
					name = current.projectile,
					position = source_point,   
					source = unit.vehicle,
					target = unit.attack_target, 
					speed = current.starting_speed}
			end
		end
		if current.type == "stream" then
			unit.turret.surface.create_entity{
				name = current.stream,
				position = source_point,   
				source = unit.vehicle,
				target = unit.attack_target, 
				speed = current.starting_speed}
		end
		if current.source_effects then 
			if current.source_effects.type then 
				unit_fire_source_effect(unit, current.source_effects, source_point, target_point)
			else 
				for _, source_effect in ipairs(current.source_effects) do 
					unit_fire_source_effect(unit, source_effect, source_point, target_point)
				end
			end
		end
		if current.target_effects then 
			if current.target_effects.type then 
				unit_fire_target_effect(unit, current.target_effects, source_point, target_point)
			else 
				for _, target_effect in ipairs(current.target_effects) do 
					unit_fire_target_effect(unit, target_effect, source_point, target_point)
				end
			end
		end
	end
end


local function unit_fire_gun(unit, source_point)
	local unit_type = unit_get_type(unit)
	if unit_type.gun.attack_parameters.sound then 
		unit.turret.surface.create_entity{
			name = "gunsound-"..unit_type.gun.name,
			position = source_point,   
			source = unit.turret,
			target = unit.attack_target}
	end
	if unit_type.gun.attack_parameters.shell_particle then 
		local movement = {x = (math.random() * 2 -1) * 0.1, y = (math.random() * 2 -1) * 0.1}
		unit.turret.surface.create_entity{
			name = unit_type.gun.attack_parameters.shell_particle.name,
			position = source_point,   
			source = unit.turret,
			target = unit.attack_target, 
			speed = unit_type.gun.attack_parameters.shell_particle.speed,
			movement = movement,
			frame_speed = unit_type.gun.attack_parameters.shell_particle.starting_frame_speed,
			vertical_speed = 0.1,
			height = 0.1} -- needs more testing & plug in vars
	end
end

local function unit_fire(unit)
	local gun = unit_get_type(unit).gun
	local weapon = unit.weapon
	weapon.rounds = weapon.rounds - 1
	local target_point = unit.attack_target.position
	target_point.x = target_point.x + 0.4 * (math.random() * 2 -1) 
	target_point.y = target_point.y + 0.3 * (math.random() * 2 -1) + 0.5
	local source_point = unit.turret.position
	if gun.attack_parameters.projectile_center then
		source_point = vectors_add(source_point, array_to_vector(gun.attack_parameters.projectile_center))
	end
	if gun.attack_parameters.gun_center_shift then
		source_point = vectors_add(source_point, array_to_vector(gun.attack_parameters.gun_center_shift))
	end
	if gun.attack_parameters.projectile_creation_distance then
		source_point = move_to(source_point, target_point, gun.attack_parameters.projectile_creation_distance, true )
	end
	unit_fire_gun(unit, source_point)
	unit_fire_ammo_recursive(unit, weapon.ammo.ammo_type.action, source_point, target_point)
	-- todo: instant line effect (railgun, piercing laser cannon)
	-- damage all in a line
	
end

local function unit_update_turret(unit)
	local unit_type = unit_get_type(unit)
	if not unit_type.gun then return end -- no weapon
	unit_load_ammo(unit) -- handles already loaded state
	if not unit.weapon then return end -- no loaded weapon
	local turret = unit.turret
	if unit.attack_target and ((not unit.attack_target.valid) or vectors_delta_length(unit.position, unit.attack_target.position) > unit_type.gun.attack_parameters.range) then
		unit.attack_target = nil -- invalid or out of range target
	end
	if (not unit.attack_target) and (global.tick + unit.unit_id % unit_target_search_interval) then
		unit.attack_target = turret.surface.find_nearest_enemy{position = turret.position, max_distance = unit_type.gun.attack_parameters.range, turret.force}
	end
	if unit.attack_target and unit.attack_target.valid then
		unit.target_last_tick = global.tick -- we have a valid target
		if( global.tick >= unit.attack_last_tick + unit_type.gun.attack_parameters.cooldown -- reload
				and unit_delta_angle_abs(turret.orientation,  
					orientation_from_to(turret.position, unit.attack_target.position)) < 0.05) -- turn 
			then
				unit.attack_last_tick = global.tick
				unit_fire(unit)
		end
	end
end



local function exchange_inventory(data)
	--[[data = {
		a = {
			entity = LuaEntity,
			inventory = LuaInventory,
			data = signal_container.item,
			is_hauler = bool
		},
		b = {
			entity = LuaEntity,
			inventory = LuaInventory,
			data = signal_container.item,
			is_hauler = bool
		}
	}]]--
	local response = {
		did_transfer = false,
		transfers = {}
	}
	if not (data.a and data.a.entity and data.a.inventory 
		and data.b and data.b.entity and data.b.inventory and data.b.data and data.b.data.item ) then return response end
	local inv_a = data.a.inventory
	local inv_b = data.b.inventory
	local itemdata_a = {}
	local itemdata_b = {}
	if data.a.data and data.a.data.item then itemdata_a = data.a.data.item end
	if data.b.data and data.b.data.item then itemdata_b = data.b.data.item end
	
	for signal_name, signal_count in pairs(itemdata_b) do
		local item_name = signal_name
			
		local a_accepts = itemdata_a[item_name] and itemdata_a[item_name].count or 0
		local b_target = itemdata_b[item_name].count
		
		local a_items = inv_a.get_item_count(item_name)
		local b_items = inv_b.get_item_count(item_name)
		
		--send_message("unit a (" .. unit.unit_id .. ") accepts "..a_accepts.." has " .. a_items .. " to unit b (" .. other_unit.unit_id .. ") targets "..b_target.." has " .. b_items)
		
		local transfer_b_a = b_items - b_target 
		-- negative is b asking for items
		-- positive is b pushing items (always positive if other_signal_count.count is negative)
		
		if data.b.is_hauler and transfer_b_a < 0 then
			-- hauler signal represents capacity, not target
			-- only transfer from other to self
			transfer_b_a = 0
		end
		
		transfer_b_a = math.min(transfer_b_a, b_items) -- can't push more than B has
		transfer_b_a = math.min(transfer_b_a, math.max(0, a_accepts - a_items)) -- can't push more than a will accept
		transfer_b_a = math.max(transfer_b_a, -a_items) -- can't pull more than A has
		
		local pusher = nil
		local pusher_inv = nil
		local puller = nil 
		local puller_inv = nil
		local items_to_transfer = transfer_b_a
		local direction = 1
		if transfer_b_a > 0 then 
			puller = data.a.entity
			puller_inv = data.a.inventory
			pusher = data.b.entity
			pusher_inv = data.b.inventory
		elseif transfer_b_a < 0 then 
			items_to_transfer = -transfer_b_a
			direction = -1
			puller = data.b.entity
			puller_inv = data.b.inventory
			pusher = data.a.entity
			pusher_inv = data.a.inventory
		end
		if pusher and puller and items_to_transfer > 0 then
			local inserted_count = puller.insert({name=item_name, count=items_to_transfer}) 
			-- insert to entity not directly to inventory 
			-- puts fuel and ammo in the right place.
			if inserted_count > 0 then
				pusher_inv.remove({name=item_name, count=inserted_count})
				response.did_transfer = true
				response.transfers[item_name] = {name=item_name, count=inserted_count * direction}
			end
		end
	end
	return response
end


local function unit_vehicle_exchange_inventory(unit)
	if (global.tick + unit.unit_id) % 60 == 0 then
		-- once per second
		if not (unit.data and unit.data.item) then return end
		
		local did_transfer = false
			
		local inv_a = unit.vehicle.get_inventory(defines.inventory.car_trunk)
		
		local test_vehicles = unit.vehicle.surface.find_entities_filtered{
			type="car", 
			area={{x=unit.vehicle.position.x-5,y=unit.vehicle.position.y-5},{x=unit.vehicle.position.x+5,y=unit.vehicle.position.y+5}},
			force=unit.vehicle.force}
			
		local other_units = {}
		for _, test_vehicle in pairs(test_vehicles) do 
			local other_unit = unit_find_from_entity(test_vehicle)
			if other_unit and other_unit.unit_id ~= unit.unit_id then
				other_units[other_unit.unit_id] = other_unit
			end
		end
		
		for _, other_unit in pairs(other_units) do 
			if other_unit.vehicle.valid and other_unit.data and other_unit.data.item then 
				local inv_b = other_unit.vehicle.get_inventory(defines.inventory.car_trunk)
				if not inv_b then break end
				
				local response = exchange_inventory({
					a = {
						entity = unit.vehicle,
						inventory = inv_a,
						data = unit.data or {},
						is_hauler = unit.unit_type == "vehicle-hauler"
					}, 
					b = {
						entity = other_unit.vehicle,
						inventory = inv_b,
						data = other_unit.data or {},
						is_hauler = other_unit.unit_type == "vehicle-hauler"
					}, 
				})
				if response.did_transfer then did_transfer = true end
				
			end
		end
		
		if did_transfer then
			unit.vehicle.surface.create_entity{
				name = "flying-text",
				position = unit.position,
				color = {r = 1, g = 1, b = 1, a = 0.5},
				text = {"inventory-transferred"}
			}
		end
		
	end
end

-- control-unit-movement


local function unit_update_state(unit) 
	-- this will update things like last position so should only be called once per tick
	local unit_type = unit_get_type(unit)
		
	unit.position_last = unit.position
	unit.position = unit.vehicle.position
	unit.speed = vector_length(vectors_delta(unit.position, unit.position_last))
	
	if 	math.floor(unit.position.x) ~= math.floor(unit.position_last.x) and
		math.floor(unit.position.y) ~= math.floor(unit.position_last.y)
	then --if unit.speed > 0.0001 then 
		unit.move_last_tick = global.tick
	end
	
	if unit.damage_target and unit.damage_target.valid then
		if unit.damage_target.health < damage_target_max_health then
			-- if the damage_target takes damage apply it to the vehicle
			-- (automated vehicles seem to not get attacked)
			unit.vehicle.health = unit.vehicle.health + unit.damage_target.health - damage_target_max_health
			unit.damage_target.health = damage_target_max_health
			if unit.vehicle.health < 1 then 
				unit.vehicle.health = 1
				unit.vehicle.damage(damage_target_max_health, unit.vehicle.force, "laser")
			end
			if not unit.vehicle or not unit.vehicle.valid then return end
		end
		unit.damage_target.teleport(unit.vehicle.position)
	end
		
	if unit.mode == "drive" then -- full manual control of base and turret
		unit.target_angle = nil
		unit.target_speed = 0
		unit.target_position = nil
		unit.safe_target_position = nil
	elseif unit.mode == "vehicle" then -- move based on target speed and angle, or act as a turret
		unit.safe_target_position = nil
		if unit.energy > 0 then
			unit_rotate_to_target_angle(unit)
			unit_speed_to_target_speed(unit)
		end
		if unit.target_position and unit.energy > 0 then
			if vectors_delta_length(unit.vehicle.position, unit.target_position) > navigator_minimum_range then
				unit.mode = "unit"
			end
		end
	elseif unit.mode == "vehicle_move_to" then -- head straight towards the target position
	
		if not unit.target_position then 
			unit.mode = "vehicle"
		else
			unit.navigator_fails = 0
			unit.stuck = (unit.stuck or 0) + 1
			if not unit.safe_target_position then 
				local save_pos = unit.vehicle.position
				unit.vehicle.teleport({x = save_pos.x, y = save_pos.y + 10}) -- move out of the way
				unit.safe_target_position = unit.vehicle.surface.find_non_colliding_position(
					unit_get_type(unit).vehicle_whole, -- name of type
					unit.target_position, -- position
					10, -- radius
					0.25 -- precision 
				)
				unit.vehicle.teleport(save_pos) -- move back
				if not unit.safe_target_position then unit.safe_target_position = unit.target_position end -- fallback
			end
			local distance = vectors_delta_length(unit.vehicle.position, unit.safe_target_position)
			if distance < 0.25 then
				unit.mode = "vehicle"
				unit.target_angle = nil
				unit.target_speed = 0
				unit.target_position = nil
			else
				if unit.stuck > 3 * 60 then -- limit this mode to a few seconds
					if (unit_type.collides_with_ground or unit_type.is_flying) then
						unit.stuck = 0
						unit_nudge(unit) -- for boat
					else
						unit.target_angle = nil
						unit.target_speed = 0
						unit.mode = "unit"
					end
				else 
					local dx = unit.safe_target_position.x - unit.position.x
					local dy = unit.safe_target_position.y - unit.position.y
					unit.target_angle = vector_to_orientation_xy(dx, dy)
					unit.target_speed = (0.25 + distance) / 50 -- auto speed by vector length
					if unit.energy > 0 then
						unit_rotate_to_target_angle(unit)
						unit_speed_to_target_speed(unit)
					end
				end
			end
			
		end
	elseif unit.mode == "unit" then -- use a unit navigator for pathfinding
		
		-- this needs a cleanup
		local distance_to_target = vectors_delta_length(unit.vehicle.position, unit.target_position)
		local navigator_distance_to_target = vectors_delta_length(unit.navigator.position, unit.target_position)
		local distance_to_navigator = vectors_delta_length(unit.vehicle.position, unit.navigator.position)
		local target_angle = orientation_from_to(unit.vehicle.position, unit.navigator.position)
		unit_rotate_to_angle(unit.vehicle, target_angle, unit_type.rotation_speed, true)
		local turn_still_required = unit_delta_angle_abs(unit.vehicle.orientation, target_angle)
		-- slow down near target or too close to navigator
		local target_speed = math.min(distance_to_target / 100, math.max(0, (distance_to_navigator-0.1) / 10))
		if math.abs(turn_still_required) > 10 / 360 then -- 5 degree tolerance
			target_speed = 0 -- slow down and turn
		end
		unit.vehicle.speed = unit.vehicle.speed * (1 - (unit_type.friction + 0.0001))-- ghost has no friction?
		unit_speed_to(unit, target_speed)
		
		local forward_vector = orientation_to_vector(unit.vehicle.orientation, 1)
		local clamped_movement = vector_dot_projection( forward_vector, vectors_delta(unit.vehicle.position, unit.navigator.position))
		local forward_position = move_to(unit.vehicle.position, vectors_add(unit.vehicle.position, clamped_movement), math.max(0, unit.vehicle.speed/4))
		local direct_position = move_to(unit.vehicle.position, unit.navigator.position, math.max(0, unit.vehicle.speed/4))
		local mixed_position = lerp_vectors(forward_position, direct_position, 0.3)
		unit.vehicle.teleport(mixed_position)
		if distance_to_navigator > 2.5 and unit.navigator_last_position then
			unit.navigator.teleport(unit.navigator_last_position) -- halt
		end
		
		if navigator_distance_to_target < navigator_minimum_range then
			unit.mode = "vehicle_move_to"
			unit.stuck = 0
		elseif unit_check_navigator_stop(unit, unit.target_position, distance_to_target) then
			unit.mode = "vehicle"
		else
			if distance_to_target >= unit.min_distance_to_target then
				if not unit.stuck then
					unit.stuck = 0
				else
					unit.stuck = unit.stuck + 1
				end
				if unit.stuck > 3 * 60 then
					unit.stuck = 0
					unit.navigator_fails = unit.navigator_fails and unit.navigator_fails + 1 or 1
					if unit.navigator_fails > 3 then -- try direct for a few seconds
						unit.mode = "vehicle_move_to"
						unit.safe_target_position = nil
					else
						unit.navigator.teleport(unit.vehicle.position)
						unit_nudge(unit)
						unit_navigate_to_target_position(unit)
					end
				end
			else
				unit.stuck = 0
			end
		end
		
		unit.navigator_last_position = unit.navigator.position
		unit.min_distance_to_target = math.min(unit.min_distance_to_target or distance_to_target, distance_to_target)
	end
	
	if unit.turret then 
		unit.turret.teleport( vectors_add({x = unit.vehicle.position.x, y = unit.vehicle.position.y + turret_y_offset}, orientation_to_vector(unit.vehicle.orientation, unit.vehicle.speed)))
		if(unit.attack_target and unit.attack_target.valid) then
			unit_rotate_to_angle(unit.turret, orientation_from_to(unit.turret.position, unit.attack_target.position ), unit_type.turret_rotation_speed, false)
		else
			unit_rotate_to_angle(unit.turret, unit.vehicle.orientation, unit_type.turret_rotation_speed, false)
		end
		unit_update_turret(unit)
	end
	
	if unit.vehicle.health ~= unit.health then
		if unit.vehicle.health < unit.health then
			-- negate 0.1 from each damage instace (soft collisions)
			-- this is targeting impacts, may inadvertently nerf enemy dot attacks
			unit.vehicle.health = min(unit.vehicle.health + 0.01, unit.health) 
			-- nudge unit to not get stuck in a wall
			unit_on_damage_taken(unit)
		end
		unit.health = unit.vehicle.health
	end
	
	if unit.unit_type == "vehicle-hauler" then 
		unit_vehicle_exchange_inventory(unit)
	end
	
	if unit.vehicle then -- update energy state, consume based on speed
		if math.abs(unit.vehicle.speed) > 0.01 then 
			-- vehicles that slowly apporach a destination get stuck where the speed is non-0 but never progress to the next pixel. 
			local energy_used = math.abs(unit.vehicle.speed) * unit_type.weight * 50 / (unit_type.effectivity or 1)-- * multiplier
			unit.energy = unit.energy - energy_used
		end
		if unit.energy < 10000 then	-- consume fuel
			unit_consume_fuel(unit)
		end
		if unit.energy < -1 then
			unit.energy = -1
		end
		unit.vehicle.energy = unit.energy > 0 and 100000 or 0
		
		-- lamp and sound
		if unit.energy > 0 then
			local lamp_position = unit.vehicle.position
			if (unit.speed > 0.001 or unit.mode == "unit") and not unit.vehicle.passenger then
				if unit.lamp then
					unit.lamp = destroy_entity(unit.lamp)
				end
				if unit.lamp_sound and unit.lamp_sound.valid and (global.tick + unit.unit_id) % 180 == 0 then 
					-- limit duration, fire is awkward
					unit.lamp_sound = destroy_entity(unit.lamp_sound)
				end
				if not (unit.lamp_sound and unit.lamp_sound.valid) then 
					unit.lamp_sound = unit_create_entity_from_entity(unit, unit_type.lamp_sound, unit.vehicle, false )
					unit.lamp_sound.destructible = false
					unit.lamp_sound.operable = false
				end
				unit.lamp_sound.teleport(lamp_position)
			else 
				if unit.lamp_sound then
					unit.lamp_sound = destroy_entity(unit.lamp_sound)
				end
				if unit.lamp and unit.lamp.valid and (global.tick + unit.unit_id) % 180 == 0 then 
					-- limit duration, fire is awkward
					unit.lamp = destroy_entity(unit.lamp)
				end
				if not (unit.lamp and unit.lamp.valid) then 
					unit.lamp = unit_create_entity_from_entity(unit, unit_type.lamp, unit.vehicle, false )
					unit.lamp.destructible = false
					unit.lamp.operable = false
					unit.lamp.teleport(lamp_position)
				end 
				unit.lamp.teleport(lamp_position)
			end
		else
			if unit.lamp then
				unit.lamp = destroy_entity(unit.lamp)
			end
			if unit.lamp_sound then
				unit.lamp_sound = destroy_entity(unit.lamp_sound)
			end
		end
	end
end


local function unit_set_command(data)
	-- can be called remotely
	--data.unit_id or data.unit 
	--data.target_speed
	--data.target_angle(0-1)
	--data.target_position (if sending to a tile try to send to the tile center (+0.5, +0.5)
	local unit = data.unit
	
	if not unit and data.unit_id then
		unit = global.unit.units[data.unit_id]
	end
	
	if unit then
		if data.target_position then
			unit.order_last_tick = global.tick
			unit_set_target_position(unit, data.target_position)
		else 
			if data.target_speed then
				unit.order_last_tick = global.tick
				unit.target_speed = data.target_speed
				unit.target_position = nil
				unit.mode = "vehicle"
			end
			if data.target_angle then
				unit.order_last_tick = global.tick
				unit.target_angle = data.target_angle % 1 
				unit.target_position = nil
				unit.mode = "vehicle"
			end
		end
		return true
	end
	return false
end




--control-vehicle-depot
-- globel vehicle_depot[unit_number]

local function struct_create_or_revive(entity_type, surface, area, position, force) -- based on aai-programmable-structures
	-- position MUST be in area for revive return to work
	local ghost = false
	local ghosts = surface.find_entities_filtered{
		area=area,
		name="entity-ghost",
		force=force}
	for _, each_ghost in pairs(ghosts) do
		if each_ghost.valid and each_ghost.ghost_name == entity_type then 
			if ghost then
				each_ghost.destroy()
			else 
				local result = each_ghost.revive()
				if not each_ghost.valid then
					ghost = true
				else 
					each_ghost.destroy()
				end
			end
		end
	end
	
	if ghost then 
		for _, entity in pairs(surface.find_entities_filtered{
			area=area,
			name=entity_type,
			force=force,
			limit=1}) do
			entity.direction = defines.direction.south
			entity.teleport(position)
			return entity
		end
	else
		return surface.create_entity{
			name=entity_type, 
			position=position, 
			force=force,
			fast_replace = true}
	end
end

local function vehicle_depot_manage_entity(entity)
	if entity.valid and entity.name == "vehicle-depot-base" then
		if not global.vehicle_depot then global.vehicle_depot = {} end
		local depot = {}
		depot.sub = {}
		depot.sub.base = entity
		--entity.active = false
		-- create chest
		local chest = struct_create_or_revive(
			"vehicle-depot-chest", -- name
			--"iron-chest", -- name
			entity.surface, -- surface
			{{entity.position.x - 1, entity.position.y - 1}, {entity.position.x + 1, entity.position.y + 1}}, -- ghost search area
			{x = entity.position.x, y =  entity.position.y},-- position
			entity.force)
		depot.unit_number = chest.unit_number
		depot.entity = chest
		-- create combinator
		local combinator = struct_create_or_revive(
			"vehicle-depot-combinator", -- name
			entity.surface, -- surface
			{{entity.position.x - 4.5, entity.position.y - 4.5}, {entity.position.x + 4.5, entity.position.y + 4.5}}, -- ghost search area
			{x = entity.position.x + 4, y =  entity.position.y - 3},-- position
			entity.force) -- force
		combinator.destructible = false
		entity.destructible = false
		depot.sub.combinator = combinator
		global.vehicle_depot[chest.unit_number] = depot
	end
end

local function vehicle_depot_unmanage(depot)
	if not depot then return end
	for _, subentity in pairs(depot.sub) do 
		if subentity.valid then
			subentity.destroy()
		end
		depot.sub[_] = nil
	end 
	global.vehicle_depot[depot.unit_number] = nil
end

local function vehicle_depot_unmanage_entity(entity)
	if entity.valid and entity.name == "vehicle-depot-chest" then
		if global.vehicle_depot then
			local depot = global.vehicle_depot[entity.unit_number]
			vehicle_depot_unmanage(depot)
			global.vehicle_depot[entity.unit_number] = nil
		end
	end
end

local function vehicle_depot_get_circuit_inputs(depot)
	if depot and depot.sub and depot.sub.combinator then
		local combinator = depot.sub.combinator
		local inputs = {} 
		local network = combinator.get_circuit_network(defines.wire_type.red)
		local network_found = false
		if network then
			network_found = true
			for _, signal_count in pairs(network.signals) do
				signal_container_add(inputs, signal_count.signal, signal_count.count)
			end
		end
		network = combinator.get_circuit_network(defines.wire_type.green)
		if network then
			network_found = true
			for _, signal_count in pairs(network.signals) do
				signal_container_add(inputs, signal_count.signal, signal_count.count)
			end
		end
		if not network_found then
			-- get straight from combinator
			local parameters = combinator.get_or_create_control_behavior().parameters.parameters
			for _, param in pairs(parameters) do
				if param.signal.name then 
					signal_container_add(inputs, param.signal, param.count)
				end
			end
		end
		return inputs
	end
end

local function vehicle_depot_exchange_inventory(depot)
	if (global.tick + depot.unit_number) % 60 == 0 then
		-- once per second
		
		-- get the effective unit data from the attached combinator or circuits
		
		local did_transfer = false
			
		local inv_a = depot.entity.get_inventory(defines.inventory.chest) -- ?
		local range = 5.5
		local test_vehicles = depot.entity.surface.find_entities_filtered{
			type="car", 
			area={{x=depot.entity.position.x-range,y=depot.entity.position.y-range},{x=depot.entity.position.x+range,y=depot.entity.position.y+range}},
			force=depot.entity.force}
		-- compansate for weird offset
		local detected = false
		local other_units = {}
		for _, test_vehicle in pairs(test_vehicles) do 
			local other_unit = unit_find_from_entity(test_vehicle)
			if other_unit then
				detected = true
				other_units[other_unit.unit_id] = other_unit
			end
		end
		
		--if not detected then return end
		local settings = vehicle_depot_get_circuit_inputs(depot)
		
		for _, other_unit in pairs(other_units) do 
			if other_unit.vehicle.valid and other_unit.data and other_unit.data.item then 
				local inv_b = other_unit.vehicle.get_inventory(defines.inventory.car_trunk)
				if not inv_b then break end
				local response
				if other_unit.unit_type ~= "vehicle-hauler" then
					response = exchange_inventory({
						a = {
							entity = depot.entity,
							inventory = inv_a,
							data = settings,
							is_hauler = true
						}, 
						b = {
							entity = other_unit.vehicle,
							inventory = inv_b,
							data = other_unit.data or {},
							is_hauler = false
						}, 
					})
				else
					response = exchange_inventory({
						b = {
							entity = depot.entity,
							inventory = inv_a,
							data = settings,
							is_hauler = false
						}, 
						a = {
							entity = other_unit.vehicle,
							inventory = inv_b,
							data = other_unit.data or {},
							is_hauler = true
						}, 
					})
				end
				
				if response.did_transfer then did_transfer = true end
				
			end
		end
		
		if did_transfer then
			depot.entity.surface.create_entity{
				name = "flying-text",
				position = depot.entity.position,
				color = {r = 1, g = 1, b = 1, a = 0.5},
				text = {"inventory-transferred"}
			}
		end
		
	end
end

local function vehicle_depot_tick() 
	if not global.vehicle_depot then return end
	for unit_number, depot in pairs(global.vehicle_depot) do 
		if (game.tick + unit_number) % 60 == 0 then
			if depot.entity.valid then 
				vehicle_depot_exchange_inventory(depot)
			else
				vehicle_depot_unmanage(depot)
			end
		end
	end
end


function remote_on_player_selected_area(event, alt)
	if (event.item == "unit-remote-control") then
		local player = game.players[event.player_index]
		if alt then
			-- move_to
			if global.player_selected_units and global.player_selected_units[event.player_index] then
				local selected_units = global.player_selected_units[event.player_index]
				local massed_data = {}
				local new_position = {
					x = math.floor((event.area.left_top.x + event.area.right_bottom.x)/2),
					y = math.floor((event.area.left_top.y + event.area.right_bottom.y)/2)
				}
				for unit_id, selected_unit in pairs(selected_units) do
					if selected_unit.unit and selected_unit.unit.vehicle and selected_unit.unit.vehicle.valid then
						local unit = selected_unit.unit
						local unit_type = unit_get_type(unit)
						local try_position = { -- random spaced in selected area
							x = math.floor(event.area.left_top.x + (event.area.right_bottom.x - event.area.left_top.x) * math.random()),
							y = math.floor(event.area.left_top.y + (event.area.right_bottom.y - event.area.left_top.y) * math.random())
						}
						local safe_position = unit.vehicle.surface.find_non_colliding_position(unit_type.buffer, try_position, 20, 2)
						massed_data[unit.unit_id] = {
							unit = unit,
							buffer = unit.vehicle.surface.create_entity{name = unit_type.buffer, position = try_position}, -- reserve the space
							target_position = safe_position,
						}
						unit_set_command({
							unit = selected_unit.unit, 
							target_position = new_position
						})
					end
				end
				for unit_id, move_data in pairs(massed_data) do
					move_data.buffer.destroy()
					unit_set_command({
						unit = move_data.unit, 
						target_position = move_data.target_position
					})
				end
			end
		else 
			-- select
			remote_deselect_units(player)
			local area = event.area
			-- non-zero
			area.left_top.x = area.left_top.x - 0.01
			area.left_top.y = area.left_top.y - 0.01
			area.right_bottom.x = area.right_bottom.x + 0.01
			area.right_bottom.y = area.right_bottom.y + 0.01
			local select_entities = player.surface.find_entities_filtered{
				area = area,
				type = "car",
				fores = player.force
			}
			global.player_selected_units[player.index] = {}
			for _, entity in pairs(select_entities) do
				local unit = unit_find_from_entity(entity)
				if unit then
					global.player_selected_units[player.index][unit.unit_id] = {unit = unit, selection = nil}
				end
			end
			if #select_entities > 0 then
				remote_show_gui(player)
			end
		end
	end
end

function remote_on_player_cursor_stack_changed(event)
	local player = game.players[event.player_index]
	if player.cursor_stack and player.cursor_stack.valid and player.cursor_stack.valid_for_read then
		if player.cursor_stack.name == "unit-remote-control" then
			--
		else
			remote_deselect_units(player)
		end
	else
		remote_deselect_units(player)
	end
end

function remote_deselect_units(player) 
	remote_hide_gui(player)
	if not global.player_selected_units then
		global.player_selected_units = {}
	elseif global.player_selected_units[player.index] then 
		local selected_units = global.player_selected_units[player.index]
		for unit_id, selected_unit in pairs(selected_units) do
			if selected_unit.selection and selected_unit.selection.valid then
				selected_unit.selection.destroy()
				selected_unit.selection = nil
			end	
			selected_units[unit_id] = nil
		end
		global.player_selected_units[player.index] = nil
	end
end

function remote_deselect_unit(player, remove_unit_id) 
	remove_unit_id = tonumber(remove_unit_id)
	remote_hide_gui(player)
	if not global.player_selected_units then
		global.player_selected_units = {}
	elseif global.player_selected_units[player.index] then 
		local selected_units = global.player_selected_units[player.index]
		local selected_unit_count = 0
		for unit_id, selected_unit in pairs(selected_units) do
			if unit_id == remove_unit_id then
				if selected_unit.selection and selected_unit.selection.valid then
					selected_unit.selection.destroy()
					selected_unit.selection = nil
				end	
				selected_units[unit_id] = nil
			else 
				selected_unit_count = selected_unit_count + 1
			end
		end
		if selected_unit_count > 0 then
			remote_show_gui(player)
		end
	end
end

function remote_on_tick() 
	if global.player_selected_units then
		for player_index, selected_units in pairs(global.player_selected_units) do
			for unit_id, selected_unit in pairs(selected_units) do
				if (selected_unit.unit and selected_unit.unit.vehicle) and selected_unit.unit.vehicle.valid then
					if selected_unit.selection and selected_unit.selection.valid then
						selected_unit.selection.teleport(selected_unit.unit.vehicle.position)
					else
						selected_unit.selection = selected_unit.unit.vehicle.surface.create_entity{
							name = "unit-selection",
							position = selected_unit.unit.vehicle.position,
						}
					end
				else
					if selected_unit.selection and selected_unit.selection.valid then
						selected_unit.selection.destroy()
						selected_unit.selection = nil
					end	
					selected_units[unit_id] = nil
				end
			end
		end
	end
end

function remote_show_gui(player)
	if player.gui.left.remote_selected_units == nil then
		update_unit_types_ids()
		local remote_selected_units = player.gui.left.add{type = "frame", name = "remote_selected_units", caption = {"text-remote-selected-units"}, direction = "vertical"}
		for unit_id, selected_unit in pairs(global.player_selected_units[player.index]) do
			local unit = selected_unit.unit
			local prototype = game.entity_prototypes[unit_get_type(unit).vehicle_whole]
			local item_name = nil
			for i_name, item in pairs(prototype.items_to_place_this) do 
				item_name = i_name
				break
			end
			local unit_button = remote_selected_units.add{
					type = "button",
					name = unit.unit_id, 
					style = "unit-button-fixed"}
			local unit_button_flow = unit_button.add{
					type = "flow",
					name = "flow", 
					direction = "horizontal"}
			unit_button_flow.add{
					type = "sprite",
					name = "unit-type-icon", 
					sprite = "item/".. item_name}
			unit_button_flow.add{
					type = "label",
					name = "unit-type-id", 
					caption=unit.unit_type_id,
					style="unit-button-label"
					}
			unit_button_flow.add{
					type = "sprite",
					name = "unit-id-icon", 
					sprite = "virtual-signal/signal-id"}
			unit_button_flow.add{
					type = "label",
					name = "unit-id", 
					caption=unit.unit_id,
					style="unit-button-label"
					}
		end
		--[[
		local units_table = remote_selected_units.add{type ="table", name = "units_table", colspan = 6, style = "units-table"}
						
		for unit_id, selected_unit in pairs(global.player_selected_units[player.index]) do
			local unit = selected_unit.unit
			local prototype = game.entity_prototypes[unit_get_type(unit).vehicle_whole]
			local item_name = nil
			for i_name, item in pairs(prototype.items_to_place_this) do 
				item_name = i_name
				break
			end
			if item_name then 
				units_table.add{
					type = "sprite-button",
					name = unit_id, 
					sprite = "item/".. item_name, 
					tooltip = "Edit Unit "..unit_id .. " Data", 
					style = "unit-button"}
			end
		end]]--
	end
end

function remote_hide_gui(player)
	if player.gui.left.remote_selected_units ~= nil then
		player.gui.left.remote_selected_units.destroy()
	end
end

function remote_on_gui_click(event)
	local player_index = event.player_index
	if game.players[player_index].gui.left.remote_selected_units ~= nil then -- avoid looping if menu is closed
		local player = game.players[player_index]
		if event.element.parent.name == "remote_selected_units" then
			remote_deselect_unit(player, tonumber(event.element.name)) 
		end
	end
end



local function unit_force_update() 
	if global.prototypes_require_load ~= false then 
		unit_load_prototypes() 
	end
	
	if not global.unit then
		global.unit = {}
	end
	if not global.unit.entities_pending_manage then
		-- delayed buffer of on_built_entity so that the script can handle assignment if responsible for creation
		global.unit.entities_pending_manage = {}
	end
	if not global.unit.unit_numbers then
		-- convert a unit_number to a unit_id
		global.unit.unit_numbers = {}
	end
	if not global.unit.next_unit_id then
		global.unit.next_unit_id = 1
	end
	if not global.unit.unit_types then -- this is units by type, not a list of unit types
		global.unit.unit_types = {}
	end
	
	for _, unit_type in pairs(global.unit_types) do 
		if not global.unit.unit_types[unit_type.name] then
			global.unit.unit_types[unit_type.name] = {} -- array
		end
	end
	
	if not global.unit.units then
		global.unit.units = {} -- by unit_id
	end
	
	-- migrations
	if global.version ~= version then
		if not global.version then 
			global.version = 0
		end	
		if global.version < 000108 then
			update_unit_types_ids()
		end
		--unit_cleanup_entities()
		global.version = version
	end
end

local function unit_on_player_enter_vehicle(player_index, vehicle)
	-- if entering a ghost or solid version then replace with a whole version
	local unit = unit_find_from_entity(vehicle)
	if unit and (unit.mode ~= "drive" or vehicle.name == unit_get_type(unit).vehicle_whole) then
		unit.mode = "drive"
		local passenger = vehicle.passenger
		vehicle.passenger = nil -- forces character out of vehicle
		unit_update_mode(unit)
		unit.vehicle.passenger = passenger -- forces character into vehicle
	end
end

local function unit_manage_entity(entity, signals)
	unit_load_prototypes() 
	for _, unit_type in pairs(global.unit_types) do 
		if entity.name == unit_type.vehicle_whole then
			unit_manage_new(entity, signals)
		end
	end
end


local function unit_tick() 
	
	for unit_number, entity in pairs(global.unit.entities_pending_manage) do 
		unit_manage_new(entity)
	end

	for _,unit in pairs(global.unit.units) do 
		if unit.vehicle and unit.vehicle.valid then
		else
			unit_unmanage(unit)
		end
	end
	
	for _,unit in pairs(global.unit.units) do 
		if unit.vehicle and unit.vehicle.valid then
			if unit.mode == "drive" and not unit.vehicle.passenger then
				unit.mode = "vehicle"
			end 
			unit_update_mode(unit)
			unit_update_state(unit)
		end
	end
end

-- control main

--player object as optional, when not present loop through all players
--insert could still fail to insert because of a full inventory, but at this point the player should have
--enough raw resources to make them
local function player_insert_items(player)
	if not global.players_given_starting_items then global.players_given_starting_items = {} end
	if not player then
		for index, player in pairs(game.players) do
			if not global.players_given_starting_items[index] then
				for _, item in pairs(starting_items) do 
					player.insert{name=item.name, count = item.count}
				end
				global.players_given_starting_items[index] = true
			end
		end
	else
		if not global.players_given_starting_items[player.index] then
			for _, item in pairs(starting_items) do 
				player.insert{name=item.name, count = item.count}
			end
			global.players_given_starting_items[player.index] = true
		end
	end
end

local function on_player_created(event)
	player_insert_items(game.players[event.player_index])
end

local function on_configuration_changed()
	global.prototypes_require_load = true
	global.unit_types = global.unit_types or {}
	global.unit_types_by_signal = global.unit_types_by_signal or {}
	global.unit_mineable_resources = global.unit_mineable_resources or {}
	unit_load_prototypes()
	player_insert_items()
end

local function on_init()
	player_insert_items()
end

local function force_update() 
	unit_force_update()
end


local function on_tick(event)
	global.tick = event.tick
	force_update()
	unit_tick()
	vehicle_depot_tick()
	remote_on_tick()
end

local function on_built_entity (event)
	unit_manage_entity(event.created_entity)
	vehicle_depot_manage_entity(event.created_entity)
end

local function on_robot_built_entity (event)
	vehicle_depot_manage_entity(event.created_entity)
end

local function on_entity_died (event)
	unit_on_entity_died(event)
	vehicle_depot_unmanage_entity(event.entity)
end

local function on_player_driving_changed_state(event)
	local player = game.players[event.player_index]
	if player.vehicle then
		unit_on_player_enter_vehicle(player_index, player.vehicle)
	end
end

local function on_player_selected_area(event)
	remote_on_player_selected_area(event, false)
end

local function on_player_alt_selected_area(event)
	remote_on_player_selected_area(event, true)
end

local function on_player_cursor_stack_changed(event)
	remote_on_player_cursor_stack_changed(event, true)
end
	
local function on_gui_click(event)
	remote_on_gui_click(event)
end

local function on_preplayer_mined_item(event)
	vehicle_depot_unmanage_entity(event.entity)
end

local function on_robot_pre_mined(event)
	vehicle_depot_unmanage_entity(event.entity)
end


-- implement custom events

local function on_entity_deployed(data) -- from structures remote
	unit_manage_entity(data.entity, data.signals)
end

--Interfaces
remote.add_interface("aai-programmable-vehicles", 
	{ 
		get_units = function() return global.unit.units end, -- returns table of units by unit id
		get_unit_types = function() unit_setup_unit_types() return unit_types end, -- returns unit type list
		get_unit_count_by_type = function(unit_type) return unit_get_count_by_type(unit_type) end, 
		get_unit_by_signal = function(data) return unit_find_from_signal(data) end, -- {signal = SignalID, count = count} returns unit
		get_unit_by_entity = function(entity) return unit_find_from_entity(entity) end,
		on_entity_deployed = function(data) return on_entity_deployed(data) end,
			--data.unit_id or data.unit 
			--data.target_speed
			--data.target_angle(0-1)
			--data.target_position
			-- returns bool of unit found
		set_unit_command = function(data) return unit_set_command(data) end,
		set_unit_data = function(data) return unit_set_data(data) end,
			
	}
)

-- bind handlers

script.on_event(defines.events.on_tick, on_tick)
script.on_event(defines.events.on_built_entity, on_built_entity)
script.on_event(defines.events.on_robot_built_entity, on_robot_built_entity) 
script.on_event(defines.events.on_entity_died, on_entity_died)
script.on_event(defines.events.on_player_driving_changed_state, on_player_driving_changed_state)
script.on_event(defines.events.on_player_selected_area, on_player_selected_area)
script.on_event(defines.events.on_player_alt_selected_area, on_player_alt_selected_area)
script.on_event(defines.events.on_player_cursor_stack_changed, on_player_cursor_stack_changed)
script.on_event(defines.events.on_player_created, on_player_created)
script.on_event(defines.events.on_gui_click, on_gui_click)

script.on_event(defines.events.on_preplayer_mined_item, on_preplayer_mined_item)
script.on_event(defines.events.on_robot_pre_mined, on_robot_pre_mined)

script.on_configuration_changed(on_configuration_changed)

script.on_init(on_init)

