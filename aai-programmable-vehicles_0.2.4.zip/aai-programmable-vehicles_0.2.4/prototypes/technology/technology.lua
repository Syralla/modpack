-- make it easier to get to vehicles
if data.raw["technology"]["engine"] then
	data.raw["technology"]["engine"].prerequisites = {"steel-processing"}
	data.raw["technology"]["engine"].unit = {
		count = 100,
		ingredients =
		{
			{"science-pack-1", 1},
		},
		time = 10
	}
end

if data.raw["technology"]["automobilism"] then
	data.raw["technology"]["automobilism"].unit = {
		count = 100,
		ingredients =
		{
			{"science-pack-1", 1},
		},
		time = 15
	}
end

if data.raw["technology"]["circuit-network"] then
	table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unit-scan"})
	table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unit-control"})
	table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unitdata-scan"})
	table.insert(data.raw["technology"]["circuit-network"].effects, {type = "unlock-recipe", recipe = "unitdata-control"})
end

if data.raw["technology"]["tanks"] then
	table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "cannon-shell-precision"})
	table.insert(data.raw["technology"]["tanks"].effects, {type = "unlock-recipe", recipe = "explosive-cannon-shell-precision"})
end