data:extend(
{
  {
    type = "item-subgroup",
    name = "vehicle-ids",
	group = "signals",
    order = "1",
  },
  {
    type = "item-subgroup",
    name = "cars",
    group = "logistics",
    order = "e-b",
  }
}
)