--CUSTOM EVENTS
--[[
currently sent events are:
on_entity_replaced : {new_entity = LuaEntity, new_entity_unit_number = uint, old_entity = LuaEntity?, old_entity_unit_number = uint}
]]--
function send_custom_event(event_name, event_data) 
	for interface_name, interface_functions in pairs(remote.interfaces) do
		if interface_functions[event_name] then
			remote.call(interface_name, event_name, event_data)
		end
	end
end

--Interfaces
remote.add_interface("aai-programmable-vehicles", 
	{ 
		get_units = function() return global.unit.units end, -- returns table of units by unit id
		get_unit_types = function() unit_setup_unit_types() return unit_types end, -- returns unit type list
		get_unit_count_by_type = function(unit_type) return unit_get_count_by_type(unit_type) end, 
		get_unit_by_signal = function(data) return unit_find_from_signal(data) end, -- {signal = SignalID, count = count} returns unit
		get_unit_by_entity = function(entity) return unit_find_from_entity(entity) end,
		on_entity_deployed = function(data) return on_entity_deployed(data) end,
			--data.unit_id or data.unit 
			--data.target_speed
			--data.target_angle(0-1)
			--data.target_position
			-- returns bool of unit found
		set_unit_command = function(data) return unit_set_command(data) end,
		set_unit_data = function(data) return unit_set_data(data) end,
			
	}
)