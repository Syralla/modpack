data:extend({
    {
        type = "custom-input",
        name = "ReverseEntireBelt",
        key_sequence = "ALT + r",
    }
})