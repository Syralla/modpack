require("util")

data:extend{
  {
    type = "radar",
    name = "launch-control-center",
    icon = "__launch-control__/graphics/icons/launch-control.png",
    flags = {"placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 2, result = "launch-control-center"},
    max_health = 300,
    corpse = "big-remnants",
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
    collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    energy_per_sector = "10MJ",
    max_distance_of_sector_revealed = 8,
    max_distance_of_nearby_sector_revealed = 6,
    energy_per_nearby_scan = "250kJ",
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input"
    },
    energy_usage = "1200kW",
    pictures =
    {
      filename = "__base__/graphics/entity/radar/radar.png",
      priority = "high",
      width = 153,
      height = 131,
      apply_projection = false,
      direction_count = 64,
      line_length = 8,
      shift = {0.875, -0.35},
      tint = {r=.9,g=.7,b=.7,a=1}
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = {
        {
          filename = "__base__/sound/radar.ogg"
        }
      },
      apparent_volume = 3,
    }
  },
  { type = "item",
    name ="launch-control-center",
    icon = "__launch-control__/graphics/icons/launch-control.png",
    flags = {},
    subgroup = "defensive-structure",
    order = "d[radar]-a[launch-control-center]",
    place_result = "launch-control-center",
    stack_size = 5
  },
  { type = "recipe", name = "launch-control-center",
    enabled = "false",
    energy_required = 3,
    ingredients =
    {
      {"radar", 4},
      {"processing-unit", 200},
      {"steel-plate", 200},
      {"concrete", 100}
    },
    result = "launch-control-center"
  }
}
