local function get_controlled_silo_count()
    local n = 0
    for k, v in pairs(global.launchControl.silos) do
        n = n + 1
    end
    return n
end

local function position_to_key(p)
    return tostring(p.x) .. "x" ..  tostring(p.y)
end

local function init_gui()
  for _, player in pairs(game.players) do
    if player.gui.top.launchControlGUI == nil then
       player.gui.top.add{type="frame", name="launchControlGUI", style="lc_frame"}
       local lcGUI = player.gui.top.launchControlGUI
       lcGUI.add{type="button",name="lcIcon",caption="Launch Control",style="lc_icon"}
--     lcGUI.add{type="label",name="lcInfo",style="lc_info"}
    end
  end
end

local function destroy_gui()
    for _, player in pairs(game.players) do
        if player.gui.top.launchControlGUI then
            player.gui.top.launchControlGUI.destroy()
        end
    end
end

local function update_gui()
  local noLaunchControl = next(global.launchControl.buildings) == nil
  if noLaunchControl then
      destroy_gui()
      return
  end

  init_gui()
  local message = tostring(get_controlled_silo_count())
  for _, player in pairs(game.players) do
    local lcGUI = player.gui.top.launchControlGUI
    lcGUI.lcIcon.caption= message
  end
end


local function find_around(entity, name)
    local p = entity.position
    local range = 32 * 6 --chunk_size * event.radar.max_distance_of_nearby_sector_revealed
    local surface = entity.surface
  
    return surface.find_entities_filtered{
        area = {{p.x-range,p.y-range},{p.x+range, p.y+range}},
        name= name
    }
end
local function find_silos_around(entity)
    return find_around(entity,"rocket-silo")
end
local function find_launch_controls_around(entity)
    return find_around(entity,"launch-control-center")
end

local function add_launch_control(entity)
    local new_building = {
        position = entity.position,
        silos = find_silos_around(entity)
    }
    
    for _,silo in pairs(new_building.silos) do
        local key = position_to_key(silo.position)
        global.launchControl.silos[key] = silo
    end
    
    local key = position_to_key(entity.position)
    global.launchControl.buildings[key] = new_building
    
    update_gui()
end

local function get_launch_control(entity)
    local key = position_to_key(entity.position)
    local building = global.launchControl.buildings[key]
    if building == nil then
        add_launch_control(entity)
        building = global.launchControl.buildings[key]
    end
    return building
end

local function is_tracked_silo(silo)
    for _, b2 in pairs(global.launchControl.buildings) do
        for _, b2silo in ipairs(b2.silos) do
            if b2silo.position.x == silo.position.x
               and b2silo.position.y == silo.position.y then
               return true
            end
        end
    end
    return false
end

local function remove_launch_control(entity)
    local key = position_to_key(entity.position)
    local building = global.launchControl.buildings[key]
    global.launchControl.buildings[key] = nil
    
    if building == nil then
        building = {
            position = entity.position,
            silos = find_silos_around(entity)
        }
    end
    
    for _, silo in ipairs(building.silos) do
        if not is_tracked_silo(silo) then
            global.launchControl.silos[position_to_key(silo.position)] = nil
        end
    end
    
    update_gui()
end

local function add_rocket_silo(silo)
    for _,entity in pairs(find_launch_controls_around(silo)) do
        local entity_key = position_to_key(entity.position)
        local building = global.launchControl.buildings[entity_key]
        building.silos[#building.silos + 1] = silo
    end
    local silo_key = position_to_key(silo.position)
    global.launchControl.silos[silo_key] = silo
    
    update_gui()
end

local function remove_rocket_silo(silo)
    for _,entity in pairs(find_launch_controls_around(silo)) do
        local entity_key = position_to_key(entity.position)
        local building = global.launchControl.buildings[entity_key]
        for index, entry in ipairs(building.silos) do
            if entry.position.x == silo.position.x and
               entry.position.y == silo.position.y then
               building.silos[index] = building.silos[#building.silos]
               building.silos[#building.silos] = nil
               break
            end
        end
    end
    
    local silo_key = position_to_key(silo.position)
    global.launchControl.silos[silo_key] = nil
    
    update_gui()
end

---

script.on_init(function()
    if global.launchControl == nil then
        global.launchControl = {
            version = 4,
            buildings = {},
            silos = {}
        }
    end
end)

script.on_load(function()
    if global.launchControl == nil or global.launchControl.version ~= 4 then
        global.launchControl = {
            version = 4,
            buildings = {},
            silos = {}
        }
    end
    --destroy_gui()
end)

--game.on_event(defines.events.on_tick, update_gui)
local on_remove_dispatch = {
    ["launch-control-center"] = remove_launch_control,
    ["rocket-silo"] = remove_rocket_silo
}
local on_built_dispatch = {
    ["launch-control-center"] = add_launch_control,
    ["rocket-silo"] = add_rocket_silo
}

local function on_remove_entity(event)
    local f = on_remove_dispatch[event.entity.name]
    if f then f(event.entity) end
end

local function on_built_entity(event)
    local f = on_built_dispatch[event.created_entity.name]
    if f then f(event.created_entity) end
end

script.on_event(defines.events.on_built_entity,on_built_entity)
script.on_event(defines.events.on_robot_built_entity,on_built_entity)
script.on_event(defines.events.on_preplayer_mined_item,on_remove_entity)
script.on_event(defines.events.on_robot_pre_mined,on_remove_entity)

script.on_event(defines.events.on_sector_scanned, function(event)
    if event.radar.name ~= "launch-control-center" then return end
    
    local silos = get_launch_control(event.radar).silos
    for _,silo in pairs(silos) do
        -- The satellite inventory (#5) is undocumented and non-existent
        -- unless ready to launch...
        -- This will launch when anything is inside. So automated fish launching
        -- will work as well. Or orbital ion cannons.
        local inventory = silo.get_inventory(5)
        if inventory ~=nil and not inventory.is_empty() then
           silo.launch_rocket()
           return
        end
    end
end)
