require("utils")
require("config")

require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")

