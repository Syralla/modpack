data:extend({

  {
    type = "recipe",
    name = "Robot-Charge-Station",
    enabled = "false",
    ingredients =
    {
      {"steel-plate", 10},
      {"copper-cable", 15},
	  {"electronic-circuit", 15},
      {"advanced-circuit", 15}
    },
    result = "Robot-Charge-Station",
    energy_required = 12
  }

})