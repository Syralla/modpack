# RoboCharge
Mod that adds a new small tower that can recharge robots, though they can't dock with it.

# Credits
- This mod is originally made by Factorio forum user Braddock (https://forums.factorio.com/viewtopic.php?f=87&t=3798).
- Robot tower graphics courtesy of Bob's Logistics mod by user Bobingabout (https://forums.factorio.com/viewtopic.php?f=51&t=6987).

# Installation
- Can be installed in-game (search for robot charging station or robocharge).
- Download zip file from release section and place in your mods folder.

# Changelog
### 0.0.8:
- Added support for Factorio 0.14.

### 0.0.7:
- Added: Sound effects.
- Changed: max_health from 200 to 300.
- Changed: input_flow_limit to 5MW (To match normal roboport).
- Changed: buffer_capacity to 100MJ (To match normal roboport).
- Changed: recharge_minimum to 40MJ (To match normal roboport).
- Changed: energy_usage to 50kW (To match normal roboport).
- Changed: charging_energy to 1000kW (To match normal roboport).

### 0.0.6:
- Initial release.
