data.raw["player"]["player"].light =
    {
      {
        intensity = 0.9,
        size = 150,
      } 
    }
data.raw["car"]["car"].light =
	{
	  {
		intensity = 0.9,
		size = 150,
	  }
   }
data.raw["car"]["tank"].light =
	{
	  {
		intensity = 0.9,
		size = 150,
	  }
   }
data.raw["locomotive"]["diesel-locomotive"].front_light =
   {
	  {
		intensity = 0.9,
		size = 150,
	  },
	  {
		intensity = 0.9,
		size = 150,
	  }
   }
data.raw["locomotive"]["diesel-locomotive"].stand_by_light =
   {
	  {
		color = {b=1},
		shift = {-0.6, -3.5},
		size = 2,
		intensity = 0.5
	  },
	  {
	  intensity = 0.9,
	  size = 60,
	  }
   }