if not factorissimo then factorissimo = {} end
if not factorissimo.config then factorissimo.config = {} end

require("config")

require("prototypes.entity.factory")
require("prototypes.entity.utility")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")
require("prototypes.tile")
