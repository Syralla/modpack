data:extend(
{
  {
    type = "item",
    name = "ultimate-solar",
    icon = "__Advanced-Electric__/graphics/ultimate-solar/ultimate-solar-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "d[solar-panel]-a[solar-panel]",
    place_result = "ultimate-solar",
    stack_size = 50
  }
}
)
