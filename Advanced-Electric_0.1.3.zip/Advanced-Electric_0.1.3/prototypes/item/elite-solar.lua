data:extend(
{
  {
    type = "item",
    name = "elite-solar",
    icon = "__Advanced-Electric__/graphics/elite-solar/elite-solar-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "d[solar-panel]-a[solar-panel]",
    place_result = "elite-solar",
    stack_size = 50
  }
}
)
