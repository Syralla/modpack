data:extend(
{
  {
    type = "item",
    name = "advanced-accumulator",
    icon = "__Advanced-Electric__/graphics/advanced-accumulator/advanced-accumulator-icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
    order = "e-b",
    place_result = "advanced-accumulator",
    stack_size = 50
  }
}
)
