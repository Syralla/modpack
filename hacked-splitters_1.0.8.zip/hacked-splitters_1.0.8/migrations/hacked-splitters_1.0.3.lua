for index, force in pairs (game.forces) do
   local technologies = force.technologies;
   local recipes = force.recipes;

   if technologies["logistics"].researched then
      recipes["hacked-splitter"].enabled = true
   end
   if technologies["logistics-2"].researched then
      recipes["hacked-fast-splitter"].enabled = true
   end
   if technologies["logistics-3"].researched then
      recipes["hacked-express-splitter"].enabled = true
   end

   -- Bob's Logistics
   if (technologies["bob-logistics-4"] and
       technologies["bob-logistics-4"].researched) then
      recipes["hacked-green-splitter"].enabled = true
   end
   if (technologies["bob-logistics-5"] and
       technologies["bob-logistics-5"].researched) then
      recipes["hacked-purple-splitter"].enabled = true
   end
end
