require "prototypes.vanilla"

if bobmods and bobmods.logistics then
   require "prototypes.bobs"
end
