#Hacked Splitters

*Hacked Splitters* mods [Factorio](https://www.factorio.com), adding a
 new class of splitters—the "hacked splitter". These splitters
 perfectly balance transport belt inputs, but can no longer
 effectively manage multi-item belts (though you are willing to try).

Hacked splitters are not special entities; they are true
splitters. They can be placed over vanilla splitters and vice
versa. You can see them in action
[here](https://gfycat.com/ImperfectHiddenGrayfox) and
[here](https://gfycat.com/GrizzledQuarrelsomeHoverfly).

*Hacked Splitters* is released under this
 [`LICENSE`](https://bitbucket.org/doktorstick/hacked-splitters/src/tip/LICENSE?fileviewer=file-view-default).

#Releases

###1.0.8 `0xCC08`

**Released** 2016-09-23

* Handle multiple `robot_pre_mined` events for same item (issue #8).

###1.0.7 `0xCC07`

**Released** 2016-09-23

* Performance improvements;
* Repair older upgrade-planner save files; and
* Fixed migration from 1.0.5 (reported by [Doublespin](https://mods.factorio.com/mods/Doublespin)).


###1.0.6 `0xCC06`

**Released** 2016-09-10

* Fixed case where three of four outbound lines were blocked (issue #5).

###1.0.5 `0xCC05`

**Released** 2016-08-26

* Factorio 0.14 update.

###1.0.4 `0xCC04`

**Released** 2016-08-22

* An offending mod was wiping out the global `util` module. Instead of
  relying on the global namespace, `require "util"` when needed (issue #2).

###1.0.3 `0xCC03`

**Released** 2016-08-21

* Support for Bob's Logistics mod.
* Removed splitter images and refactored the entities to use animation layers for the hatch marks.
* Recalculate update frequency when dependent mods (*e.g.,* `base`) are updated in the event they change their belts' speeds.

###1.0.2 `0xCC02`

**Released** 2016-08-18

* Patch for case where the entity becomes invalid (issue #1).

###1.0.1 `0xCC01`

**Released** 2016-08-15

* Removed `session_tick` as it was not really needed and there was
  a suggestion that it might cause a multiplayer desync.
* Fixed express belt compression in main processing loop (reported by
  [goofy183](https://www.reddit.com/user/goofy183)).

##1.0.0 `PWNED`

**Released:** 2016-08-13

This release marks the debut of *Hacked Splitters*. It includes a
small but functional set of features:

* Three new entities—hacked splitter, hacked fast splitter, and hacked
  express splitter, which build upon the splitter, fast splitter, and
  express splitter, respectively;

* Extremely minor graphics tweaks for the splitter icons and
  entities. They are denoted by three white hatch marks on the
  splitter bezels; and

* English localization.


# Roadmap

##1.1 `FPLv2`

This release was planned to be much larger (see `Hackathon` below for
more info). I'm investigating the feasibility of creating a splitter
circuit base-station by tinkering with combinators to see if they can
read state from entities not directly attached, or by having entities
broadcast to them.

##2.0 `Hackathon`

**Status:** Indefinitely postponed

The original goal of this release is to add circuit logic to the
splitter. The plan was that this would be done as part of `FPLv2`.
Oh, how ignorant was I.

I had thought that by adding circuit connection attributes to the
entities paired with a little Lua code, an item would inherit circuit
properties. Seemed reasonable. Sufficed to say that as of 0.13, this
did not work. Below is a small catalog of things I wanted to do.

* Backpressure signal (output). Output green when all output lines are
  available, yellow for some pressure, and red when all lines have
  backpressure;

* Throughput signal (output);

* Item mask for split control (input). A constant combinator
  outputting an item-type and masked value would control the lines
  items were split to. For example, copper plate with a value of 3
  would balance to the same output belt (lines 5 and 6);

* Update graphics to include circuit leads; and

* Recipe adjustment for +1 iron plate (circuit connections).
