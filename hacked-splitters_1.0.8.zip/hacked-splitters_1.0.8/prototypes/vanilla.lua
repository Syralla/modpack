local hacked = require "hacked"
local debug = require "..debug"


if debug.enabled then
   local fmt = hacked.moddir.."/graphics/debug/%s.png"

   for i, plate in ipairs ({"copper-plate", "iron-plate"}) do
      data.raw["item"][plate].icon = string.format (fmt, plate)
   end
end


-- Entity definitions
splitters = {"splitter", "fast-splitter", "express-splitter"}
for i, name in ipairs (splitters) do
   hacked.make_hacked_entity (name)
end


-- Item definitions
data:extend({
      {
         type = "item",
         name = "hacked-splitter",
         icon = "__hacked-splitters__/graphics/icons/hacked-splitter.png",
         flags = {"goes-to-quickbar"},
         subgroup = "belt",
         order = "c[splitter]-a[splitter]-b[hacked-splitter]",
         place_result = "hacked-splitter",
         stack_size = 50
      },
      {
         type = "item",
         name = "hacked-fast-splitter",
         icon = "__hacked-splitters__/graphics/icons/hacked-fast-splitter.png",
         flags = {"goes-to-quickbar"},
         subgroup = "belt",
         order = "c[splitter]-b[fast-splitter]-c[hacked-fast-splitter]",
         place_result = "hacked-fast-splitter",
         stack_size = 50
      },
      {
         type = "item",
         name = "hacked-express-splitter",
         icon = "__hacked-splitters__/graphics/icons/hacked-express-splitter.png",
         flags = {"goes-to-quickbar"},
         subgroup = "belt",
         order = "c[splitter]-c[express-splitter]-d[hacked-express-splitter]",
         place_result = "hacked-express-splitter",
         stack_size = 50
      }
})


-- Recipe definitions
data:extend({
      {
         type = "recipe",
         name = "hacked-splitter",
         enabled = false,
         energy_required = 1,
         ingredients =
            {
               {"splitter", 1},
               {"copper-cable", 1},
               {"electronic-circuit", 1}
            },
         result = "hacked-splitter",
         requester_paste_multiplier = 4
      },
      {
         type = "recipe",
         name = "hacked-fast-splitter",
         enabled = false,
         energy_required = 2,
         ingredients =
            {
               {"fast-splitter", 1},
               {"copper-cable", 1},
               {"electronic-circuit", 1}
            },
         result = "hacked-fast-splitter",
         requester_paste_multiplier = 4
      },
      {
         type = "recipe",
         name = "hacked-express-splitter",
         enabled = false,
         energy_required = 2,
         ingredients =
            {
               {"express-splitter", 1},
               {"copper-cable", 1},
               {"advanced-circuit", 1}
            },
         result = "hacked-express-splitter"
      }
})


-- Technology definitions
table.insert(
   data.raw["technology"]["logistics"].effects,
   {
      type="unlock-recipe",
      recipe="hacked-splitter"
   }
)

table.insert(
   data.raw["technology"]["logistics-2"].effects,
   {
      type="unlock-recipe",
      recipe="hacked-fast-splitter"
   }
)

table.insert(
   data.raw["technology"]["logistics-3"].effects,
   {
      type="unlock-recipe",
      recipe="hacked-express-splitter"
   }
)
