-- Support for Bob's Logistics

local hacked = require "hacked"


-- Entity definitions
splitters = {"green-splitter", "purple-splitter"}
for i, name in ipairs (splitters) do
   hacked.make_hacked_entity (name)
end


-- Item definitions
data:extend({
      {
         type = "item",
         name = "hacked-green-splitter",
         icon = hacked.moddir.."/graphics/icons/hacked-green-splitter.png",
         flags = {"goes-to-quickbar"},
         subgroup = "bob-belt",
         order = "c[splitter]-d[green-splitter]-e[hacked-green-splitter]",
         place_result = "hacked-green-splitter",
         stack_size = 50
      },
      {
         type = "item",
         name = "hacked-purple-splitter",
         icon = hacked.moddir.."/graphics/icons/hacked-purple-splitter.png",
         flags = {"goes-to-quickbar"},
         subgroup = "bob-belt",
         order = "c[splitter]-e[purple-splitter]-f[hacked-purple-splitter]",
         place_result = "hacked-purple-splitter",
         stack_size = 50
      },
})


-- Recipe definitions
data:extend({
      {
         type = "recipe",
         name = "hacked-green-splitter",
         enabled = false,
         energy_required = 1,
         ingredients =
            {
               {"green-splitter", 1},
               {"copper-cable", 1},
               {"advanced-circuit", 1}
            },
         result = "hacked-green-splitter",
         requester_paste_multiplier = 4
      },
      {
         type = "recipe",
         name = "hacked-purple-splitter",
         enabled = false,
         energy_required = 2,
         ingredients =
            {
               {"purple-splitter", 1},
               {"copper-cable", 1},
               {"processing-unit", 1}
            },
         result = "hacked-purple-splitter",
         requester_paste_multiplier = 4
      },
})


-- Technology definitions
table.insert(
   data.raw["technology"]["bob-logistics-4"].effects,
   {
      type="unlock-recipe",
      recipe="hacked-green-splitter"
   }
)

table.insert(
   data.raw["technology"]["bob-logistics-5"].effects,
   {
      type="unlock-recipe",
      recipe="hacked-purple-splitter"
   }
)
