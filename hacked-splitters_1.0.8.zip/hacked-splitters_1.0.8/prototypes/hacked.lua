require "util"

local hacked = {}
hacked.moddir = "__hacked-splitters__"

-- The hacked variants of the splitters share all of the
-- characteristics of their baser counterparts. Instead of
-- copy-pasting the entity data that is subject to change, we'll
-- procedurally build the hacked splitters, updating the entity name
-- and generating new animations.

function make_anim (lst, dir)
   -- This is the default splitter animation.
   local t1 = util.table.deepcopy (lst)

   -- This is the hacked layer animation.
   local t2 = util.table.deepcopy (lst)
   t2.filename = hacked.moddir.."/graphics/layers/hacked-layer-"..dir..".png"

   return { layers = {t1, t2} }
end


function hacked.make_hacked_entity (name)
   if data.raw["splitter"][name] ~= nil then
      local hacked = "hacked-"..name
      local template = util.table.deepcopy (data.raw["splitter"][name])

      template.name = hacked
      template.minable.result = hacked

      template.structure.north = make_anim (template.structure.north, "north")
      template.structure.east = make_anim (template.structure.east, "east")
      template.structure.south = make_anim (template.structure.south, "south")
      template.structure.west = make_anim (template.structure.west, "west")

      data:extend({template})
   end
end

return hacked
