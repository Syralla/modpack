autohide_time = 180 -- time to auto-hide sticky note in ticks (180 = 3sec)
text_color = {r=1,g=1,b=0}
use_color_picker = true -- Color Picker mod (by Mooncat) will be used for changing the font color (if it has been installed separately).

