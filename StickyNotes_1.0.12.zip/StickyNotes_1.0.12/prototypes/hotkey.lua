data:extend(
	{
		{
			type = "custom-input",
			name = "notes_write_hotkey",
			key_sequence = "ALT + W",
			consuming = "script-only"
		},
	}
)