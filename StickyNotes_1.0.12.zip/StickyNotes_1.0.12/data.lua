require("utils")
require("prototypes/styles")
require("prototypes/hotkey")
require("prototypes/entities")

