    local function insertItems(player_index, itemStacks)
    local player = game.players[player_index]
    local newStacks = {}
    if itemStacks then
        if itemStacks[1] and itemStacks[1].name then
            newStacks = itemStacks
        elseif itemStacks and itemStacks.name then
            newStacks = {itemStacks}
        end
        for _, stack in pairs(newStacks ) do
            local name, count, health = stack.name, stack.count, stack.health or 1
            local inserted = player.insert({name=name, count=count, health=health})
            if inserted ~= count then
                player.surface.spill_item_stack(player.position, {name=name, count=count-inserted, health=health}, true)
            end
        end
        return newStacks[1] and newStacks[1].name and true
    end
end

local function entityProducts(entity)
    local products = entity.prototype.mineable_properties and entity.prototype.mineable_properties.products
    local itemStacks = {}
    if products then
        for _, item in pairs(products) do
            local max = entity.health and entity.prototype.max_health
            local health = (entity.health and entity.health/max) or 1
            itemStacks[#itemStacks+1] = {name=item.name, count=item.amount or math.random(item.amount_min, item.amount_max), health=health}
        end
    end
    return itemStacks
end

local function cloneEntity(entity, newPosition, player_index)
    local name, surface, force, direction, last_user = entity.name, entity.surface, entity.force, entity.direction, entity.last_user
    local specificType
    if entity.type == "belt-to-ground" then
        specificType = entity.belt_to_ground_type
    elseif entity.type == "loader" then
        specificType = entity.loader_type
    end
    local inner_name
    if entity.name == "entity-ghost" or entity.name == "tile-ghost" then
        inner_name = entity.ghost_name
    end
    entity.destroy()
    if inner_name and not surface.can_place_entity{name=inner_name,position=newPosition,direction=direction,force=force,type=specificType} then
        return false
    elseif not surface.can_place_entity{name=name,position=newPosition,direction=direction,force=force,inner_name=inner_name,type=specificType} then
        return false
    end
    local newEntity = surface.create_entity{name=name, position=newPosition, direction=direction, force=force, type=specificType, inner_name=inner_name}
    if newEntity then
        if last_user then
            newEntity.last_user = last_user
        end
        game.raise_event(defines.events.on_built_entity, {created_entity = newEntity, player_index = player_index, cursor_lock = true})
        return true
    end
end

script.on_event(defines.events.on_built_entity, function(event)
    global.cursorLocks = global.cursorLocks or {}
    global.previousHolding = global.previousHolding or {}
    local player_index = event.player_index
    local player = game.players[player_index]
    if not event.cursor_lock and not event.corrected_loader then
        local entity = event.created_entity
        local itemStacks = entityProducts(entity)
        if global.cursorLocks[player_index] then
            local products = entity.prototype.mineable_properties and entity.prototype.mineable_properties.products
            if global.cursorLocks[player_index].inputWaiting then
                if global.cursorLocks[player_index].inputWaiting == "x" then
                    global.cursorLocks[player_index] = {x = entity.position.x}
                else
                    global.cursorLocks[player_index] = {y = entity.position.y}
                end
                global.previousHolding[player_index] = player.cursor_stack.valid_for_read and player.cursor_stack.name
            elseif global.cursorLocks[player_index].x then
                if not cloneEntity(entity, {global.cursorLocks[player_index].x, entity.position.y}, player_index) and products then
                    insertItems(player_index, itemStacks)
                end
            elseif global.cursorLocks[player_index].y then
                if not cloneEntity(entity, {entity.position.x, global.cursorLocks[player_index].y}, player_index) and products then
                    insertItems(player_index, itemStacks)
                end
            end
        end
    end
end)

script.on_event("cursorlock-x", function(event)
    local player_index = event.player_index
    game.players[player_index].print({"cursorlock-locked-x"})
    global.cursorLocks = global.cursorLocks or {}
    global.cursorLocks[player_index] = {inputWaiting = "y"} -- Inverted because that makes more sense.
end)

script.on_event("cursorlock-y", function(event)
    local player_index = event.player_index
    game.players[player_index].print({"cursorlock-locked-y"})
    global.cursorLocks = global.cursorLocks or {}
    global.cursorLocks[player_index] = {inputWaiting = "x"} -- Inverted because that makes more sense.
end)

script.on_event("cursorlock-unlock", function(event)
    local player_index = event.player_index
    game.players[player_index].print({"cursorlock-unlocked"})
    global.cursorLocks = global.cursorLocks or {}
    global.cursorLocks[player_index] = nil
end)

script.on_event(defines.events.on_player_cursor_stack_changed, function(event)
    global.cursorLocks = global.cursorLocks or {}
    global.previousHolding = global.previousHolding or {}
    if game.players[event.player_index].cursor_stack.valid_for_read and game.players[event.player_index].cursor_stack.name ~= global.previousHolding[event.player_index] then
        if global.cursorLocks[event.player_index] then
            if global.cursorLocks[event.player_index].x then
                global.cursorLocks[event.player_index] = {inputWaiting = "x"}
            elseif global.cursorLocks[event.player_index].y then
                global.cursorLocks[event.player_index] = {inputWaiting = "y"}
            end
        end
    end
end)
