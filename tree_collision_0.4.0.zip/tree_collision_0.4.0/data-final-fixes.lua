for _,tree in pairs(data.raw["tree"]) do
   tree.collision_box = {{-0.05, -0.05}, {0.05, 0.05}}
end