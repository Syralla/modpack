-- If set to true then this will add in the extra ROBOT SPEED technologies
speedTech=true

-- If set to true then this will add in the extra ROBOT CAPACITY technologies
capacityTech=true

-- If set to true then this will add in the extra CHARACTER TRASH SLOT technologies
trashTech=true

-- If set to true then this will add in the extra CHARACTER LOGISTICS SLOT technologies
characterTech=true