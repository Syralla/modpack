data:extend(
{
  {
    type = "item",
    name = "underground-belt-v2",
    icon = "__Advanced-Logistics__/graphics/icons/underground-belt-v2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "underground-belt",
    order = "a[underground-belt]-b[underground-belt-v2]",
    place_result = "underground-belt-v2",
    stack_size = 50
  },
  {
    type = "item",
    name = "underground-belt-v3",
    icon = "__Advanced-Logistics__/graphics/icons/underground-belt-v3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "underground-belt",
    order = "a[underground-belt]-c[underground-belt-v3]",
    place_result = "underground-belt-v3",
    stack_size = 50
  },
  {
    type = "item",
    name = "fast-underground-belt-v2",
    icon = "__Advanced-Logistics__/graphics/icons/fast-underground-belt-v2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "underground-belt",
    order = "b[fast-underground-belt]-b[fast-underground-belt-v2]",
    place_result = "fast-underground-belt-v2",
    stack_size = 50
  },
  {
    type = "item",
    name = "fast-underground-belt-v3",
    icon = "__Advanced-Logistics__/graphics/icons/fast-underground-belt-v3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "underground-belt",
    order = "b[fast-underground-belt]-c[fast-underground-belt-v3]",
    place_result = "fast-underground-belt-v3",
    stack_size = 50
  },
  {
    type = "item",
    name = "express-underground-belt-v2",
    icon = "__Advanced-Logistics__/graphics/icons/express-underground-belt-v2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "underground-belt",
    order = "c[express-underground-belt]-b[express-underground-belt-v2]",
    place_result = "express-underground-belt-v2",
    stack_size = 50
  },
  {
    type = "item",
    name = "express-underground-belt-v3",
    icon = "__Advanced-Logistics__/graphics/icons/express-underground-belt-v3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "underground-belt",
    order = "c[express-underground-belt]-c[express-underground-belt-v3]",
    place_result = "express-underground-belt-v3",
    stack_size = 50
  }
})