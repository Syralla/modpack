 data:extend(
{
  {
    type = "item",
    name = "pipe-to-ground-v2",
    icon = "__Advanced-Logistics__/graphics/icons/pipe-to-ground-v2.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "a[pipe-to-ground]-b[pipe-to-ground-v2]",
    place_result = "pipe-to-ground-v2",
    stack_size = 30
  },
  {
    type = "item",
    name = "pipe-to-ground-v3",
    icon = "__Advanced-Logistics__/graphics/icons/pipe-to-ground-v3.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "a[pipe-to-ground-v2]-b[pipe-to-ground-v3]",
    place_result = "pipe-to-ground-v3",
    stack_size = 20
  }
})