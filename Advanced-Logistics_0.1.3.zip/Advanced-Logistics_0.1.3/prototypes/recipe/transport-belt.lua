data:extend(
{
 {
    type = "recipe",
    name = "underground-belt-v2",
    enabled = "false",
    energy_required = 1,
    ingredients =
    {
        {"iron-plate", 20},
        {"transport-belt", 15}
    },
    result_count = 2,
    result = "underground-belt-v2"
  },
   {
    type = "recipe",
    name = "underground-belt-v3",
    enabled = "false",
    energy_required = 1,
    ingredients =
    {
		{"steel-plate", 20},
		{"transport-belt", 25}
    },
    result_count = 2,
    result = "underground-belt-v3"
  },
  {
    type = "recipe",
    name = "fast-underground-belt-v2",
    enabled = "false",
    ingredients =
    {
		{"iron-plate", 20},
        {"fast-transport-belt", 15}
	},
    result_count = 2,
    result = "fast-underground-belt-v2"
  },
  {
    type = "recipe",
    name = "fast-underground-belt-v3",
    enabled = "false",
    ingredients =
    {
		{"steel-plate", 20},
		{"fast-transport-belt", 25}
    },
    result_count = 2,
    result = "fast-underground-belt-v3"
  },
  {
    type = "recipe",
    name = "express-underground-belt-v2",
    enabled = "false",
    ingredients =
    {
        {"iron-plate", 20},
        {"express-transport-belt", 15}
    },
    result_count = 2,
    result = "express-underground-belt-v2"
  },
  {
    type = "recipe",
    name = "express-underground-belt-v3",
    enabled = "false",
    ingredients =
    {
        {"steel-plate", 20},
		{"express-transport-belt", 25}
    },
    result_count = 2,
    result = "express-underground-belt-v3"
  } 
})