data:extend(
{
  {
    type = "recipe",
    name = "roboportmk2",
    enabled = false,
    ingredients =
    {
      {"roboport", 1},
      {"steel-plate", 45},
      {"alien-artifact", 5},
      {"processing-unit", 25}
    },
    result = "roboportmk2",
    energy_required = 25
  }
}
)
