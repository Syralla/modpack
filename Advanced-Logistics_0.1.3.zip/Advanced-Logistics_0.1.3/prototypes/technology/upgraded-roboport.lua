data:extend(
{
  {
    type = "technology",
    name = "roboportmk2",
    icon = "__base__/graphics/technology/construction-robotics.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "roboportmk2"
      },
    },
    prerequisites = {"construction-robotics"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 2},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 30
    },
    order = "c-k-a",
  }
}
)
