data:extend(
{ 
  {
    type = "recipe",
    name = "Single Splitter",
    enabled = "true",
    ingredients = 
    {
      {"electronic-circuit",2},
      {"iron-plate",2}
    },
    result = "Single Splitter"
  }
}
)