data:extend(
{
		 {
			type = "item",
			name = "Single Splitter",
			icon = "__Single-Splitter__/graphics/splitter.png",
			flags = { "goes-to-quickbar" },
			subgroup = "belt",
			place_result="Single Splitter",
			stack_size= 50,
		  },
})
	

