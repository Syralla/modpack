data:extend(
{
  {
    type = "technology",
    name = "fusion-robotics",
    icon = "__FusionRobots__/graphics/technology/fusion-robotics.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "construction-robot-fusion"
      },
      {
        type = "unlock-recipe",
        recipe = "logistic-robot-fusion"
      },
    },
    prerequisites = {"construction-robotics", "fusion-reactor-equipment", "logistic-robotics"},
    unit =
    {
      count = 450,
      ingredients =
      {
        {"alien-science-pack", 1},
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1}
      },
      time = 30
    },
    order = "c-k-b",
  },
})