require("prototypes.entity.construction-robot")
require("prototypes.entity.logistic-robot")
require("prototypes.technology.fusion-robots")
require("prototypes.entity.death-explosion")